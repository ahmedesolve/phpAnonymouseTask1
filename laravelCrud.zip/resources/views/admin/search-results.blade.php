@extends('admin.index')
@section('content')
<section class="admin-content">
    <div class="bg-dark">
        <div class="container  m-b-30">
            <div class="row">
                <div class="col-12 text-white p-t-40 p-b-90">
                    <h4 class="">Search Results </h4>
                </div>
            </div>
        </div>
    </div>

    <div class="container  pull-up">
        <div class="row">
            @if($categories->count() == 0)
            <div class="col-12 m-b-100">
                <div class="card">
                    <div class="card-head m-b-50 m-t-50 m-l-10 text-center">
                        <h4>Sorry! There Is No Results On Categories Table</h4>
                    </div>
                </div>
            </div>
            @else
            <div class="col-12 m-b-100">
                <div class="card">
                    <div class="card-head m-t-50 m-l-10 text-center">
                        <h4>{{ $categories->count() }} Result(s) On Categories</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive p-t-10">
                            <table id="example" class="table" style="width:100%">
                                <thead>
                                    <tr>
                                        <th><input type="checkbox" name="checkedAll[]" id="checkedAll" /></th>
                                        <th>Name</th>
                                        <th>Slug</th>
                                        <th>image</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                     @foreach($categories as $category)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="checkAll[]" class="checkSingle" value="{{ $category->id }}"/>
                                        </td>
                                        <td>{{ $category->name }}</td>
                                        <td>{{ $category->slug }}</td>
                                        <td><img class="view-img" src="{{ loadImage($category->image) }}"></td>
                                        <td>@include('admin.categories.buttons')</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th></th>
                                        <th>Name</th>
                                        <th>Slug</th>
                                        <th>Image</th>
                                        <th>Actions</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            @endif
            @if($posts->count() == 0)
            <div class="col-12 m-b-100">
                <div class="card">
                    <div class="card-head m-b-50 m-t-50 m-l-10 text-center">

                        <h4>Sorry! There Is No Results On posts Table</h4>
                    </div>
                </div>
            </div>
            @else
            <div class="col-12 m-b-100">
                <div class="card">
                    <div class="card-head m-t-50 m-l-10 text-center">
                        <h4>{{ $posts->count() }} Result(s) On Posts</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive p-t-10">
                            <table id="example" class="table" style="width:100%">
                                <thead>
                                    <tr>
                                        <th><input type="checkbox" name="checkedAll[]" id="checkedAll" /></th>
                                        <th>Title</th>
                                        <th>Slug</th>
                                        <th>Featured</th>
                                        <th>Author</th>
                                        <th>Image</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($posts as $post)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="checkAll[]" class="checkSingle" value="{{ $post->id }}"/>
                                        </td>
                                        <td>{{ $post->title }}</td>
                                        <td>{{ $post->slug }}</td>
                                        <td>
                                            @if($post->featured)
                                            <span class="badge badge-success  text-uppercase">featured</span>
                                            @else
                                            <span class="badge badge-danger  text-uppercase">Not-featured</span>
                                            @endif
                                        </td>
                                        <td>{{ $post->author() }}</td>
                                        <td><img class="view-img" src="{{ loadImage($post->image) }}"></td>
                                        <td>@include('admin.posts.buttons')</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th></th>
                                        <th>Title</th>
                                        <th>Slug</th>
                                        <th>Featured</th>
                                        <th>Image</th>
                                        <th>Actions</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            @endif
        </div>
    </div>
</section>
@include('admin.layouts.modal')
@endsection


@push('extra-css')
<!-- Additional library for page -->
<link rel='stylesheet' href='/adminPanel/baseassets/bundles/13fc3abb600e389b43865b1fa1697fc8f5ebf063.css'/>

@endpush
@push('extra-js')
<!-- Additional library for page -->
<script src='/adminPanel/baseassets/bundles/ba78fede76f682cd388ed2abbfd1e1568e76f8a4.js'></script>
<script src='/adminPanel/assets/js/checkbox.js'></script>
<!-- ajax functionality to bulk delete-->

@endpush