<div class="col-md-4 m-t-50">
	<div class="card ">
		<div class="card-media">
			<div class="card-controls">
				<a href="#" class="js-card-refresh icon"></a>
			</div>
			<img class="card-img-top" src="{{ loadImage($post->image) }}" alt="{{ $post->seo_title }}">
			</div>
			<div class="card-body">
				<h5 class="card-title">{{ $post->title }}</h5>
				<p class="card-text">{!! $post->small_description !!}</p>
				<a href="{{ route('post.show' , $post->id) }}" class="btn btn-primary">Show</a>
			</div>
		</div>
	</div>