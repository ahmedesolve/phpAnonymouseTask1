@extends('admin.index')
@section('content')
<section class="admin-content">
    <div class="bg-dark">
        <div class="container  m-b-30">
            <div class="row">
                <div class="col-12 text-white p-t-40 p-b-90">
                    <h4 class="">Admin </h4>
                    <p class="opacity-75 ">
                        Click on table rows to select them.
                    </p>
                    <a href="{{ route('admin.create') }}" class="btn m-b-30 ml-2 mr-2 btn-success"><i class="mdi mdi-plus"></i> Add Admin
                    </a>

                    <a id="bulk-delete" href="" class="hidden btn m-b-30 ml-2 mr-2 btn-danger" data-toggle="modal" data-target="#bulkDeleteModal"><i class="mdi mdi-trash"></i> Bulk Delete
                    </a>

                </div>
            </div>
        </div>
    </div>

    <div class="container  pull-up">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive p-t-10">
                            <table id="example" class="table" style="width:100%">
                                <thead>
                                    <tr>
                                        <th><input type="checkbox" name="checkedAll[]" id="checkedAll" /></th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($admins as $admin)
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="checkAll[]" class="checkSingle" value="{{ $admin->id }}"/>
                                        </td>
                                        <td>{{ $admin->name }}</td>
                                        <td>{{ $admin->email }}</td>
                                        <td>@include('admin.admins.buttons')</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th></th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Actions</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@include('admin.layouts.modal')
@endsection


@push('extra-css')
<!-- Additional library for page -->
<link rel='stylesheet' href='/adminPanel/baseassets/bundles/13fc3abb600e389b43865b1fa1697fc8f5ebf063.css'/>
<style type="text/css">
[data-notify="progressbar"] {
    margin-bottom: 0px;
    position: absolute;
    bottom: 0px;
    left: 0px;
    width: 100%;
    height: 5px;
}
</style>
@endpush
@push('extra-js')
<!-- Additional library for page -->
<script src='/adminPanel/baseassets/bundles/ba78fede76f682cd388ed2abbfd1e1568e76f8a4.js'></script>
<script src='/adminPanel/assets/js/checkbox.js'></script>
<!-- ajax functionality to bulk delete-->
<script>
    var id = [];
    $('#confirm-delete').click(function(){
        $(".checkSingle:checked").each(function() {
            id.push($(this).val());
        });
        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type:'post',
            url: '<?= url("/admin/admin/bulk-delete") ?>',
            data: {  _token: '{{csrf_token()}}' , id:id },
            success: function (data) {
             window.location.href = '{{ route('admin.index') }}'
             console.log('done');

            }
        });
    });
</script>
@if(Session::has('success_message'))
<script type="text/javascript">
  $.notify({
    // options
    icon: 'mdi mdi-check-circle',
    title: 'Success',
    message: '{{ Session::get('success_message') }}',
    },{
    // settings
    element: 'body',
    allow_dismiss: true,
    showProgressbar: true,
    placement: {
        from: "top",
        align: "right"
    },
    offset: 20,
    spacing: 10,
    z_index: 1031,
    delay: 5000,
    timer: 5000,
    animate: {
        enter: 'animated fadeInDown',
        exit: 'animated fadeOutUp'
    },
    icon_type: 'class',
    template: '<div data-notify="container" class="bootstrap-notify alert animated fadeInDown" role="alert" data-notify-position="top-right" style="display: inline-block; margin: 0px auto; position: fixed; transition: all 0.5s ease-in-out 0s; z-index: 10000; top: 30px; right: 28px;"><div class="progress" data-notify="progressbar"><div class="progress-bar bg-success" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%;"></div></div><div class="media "> <div class="avatar m-r-10 avatar-sm"> <div class="avatar-title bg-success rounded-circle"><span data-notify="icon" class="icon mdi mdi-check-circle"></span></div> </div><div class="media-body"><div class="font-secondary" data-notify="title">{1}</div> <span class="opacity-75" data-notify="message">{2}</span></div><a href="#" target="_blank" data-notify="url"></a> <button type="button" aria-hidden="true" class="close" data-notify="dismiss" style="position: absolute; right: 10px; top: 5px; z-index: 100002;"><span>x</span></button></div></div>' 
    });
</script>
@endif
@endpush