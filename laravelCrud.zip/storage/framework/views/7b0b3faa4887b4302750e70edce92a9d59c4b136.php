<?php $__env->startSection('content'); ?>
<section class="admin-content ">
    <div class="bg-dark bg-dots m-b-30">
        <div class="container">
            <div class="row p-b-60 p-t-60">

                <div class="col-lg-8 text-center mx-auto text-white p-b-30">
                    <div class="m-b-10">
                        <div class="avatar avatar-lg ">
                            <div class="avatar-title bg-info rounded-circle mdi mdi-settings "></div>
                        </div>
                    </div>
                    <h3>Site Settings </h3>
                </div>


            </div>
        </div>
    </div>
    <section class="pull-up">
        <div class="container">
            <div class="row ">
                <div class="col-lg-8 mx-auto  mt-2">
                    <div class="card py-3 m-b-30">
                     <div class="card-body">
                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                         <form enctype='multipart/form-data' action="<?php echo e(route('settings.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-row">
                             <div class="form-group col-md-6">
                                 <label for="inputEmail6">Site Name</label>
                                 <input type="text" class="form-control" name="sitename" placeholder="Site Name" value="<?php echo e(old('sitename' ,settings('sitename'))); ?>">
                             </div>
                             <div class="form-group col-md-6">
                                 <label for="inputEmail4">Site Email</label>
                                 <input type="email" class="form-control" placeholder="Site Email" value="<?php echo e(old('siteemail' ,settings('siteemail'))); ?>" name="siteemail">
                             </div>

                         </div>
                         <div class="form-row">
                             <div class="form-group col-md-12">
                                 <label for="asd">Keywods</label>
                                 <textarea class="form-control" name="sitekeywords">
                                 <?php echo old('sitekeywords' ,settings('sitekeywords')); ?>

                                 </textarea>
                             </div>
                         </div>
                         <div class="form-group">
                             <label for="inputAddress">Discription</label>
                             <textarea class="form-control summernote" name="sitedescription">
                                <?php echo old('sitedescription' ,settings('sitedescription')); ?>

                            </textarea>
                         </div>
                         <div class="form-group">
                            <?php if(!empty(settings('sitelogo'))): ?>
                                <div class="col-md-12 m-t-50 m-b-50">
                                 <img width="150" src="<?php echo e(loadImage(settings('sitelogo'))); ?>">
                                </div>
                            <?php endif; ?>
                         <label for="inputAddress" class="col-md-12">Site Logo</label>
                         <input type="file" name="sitelogo">
                         </div>
                         <div class="form-group">
                            <?php if(!empty(settings('siteicon'))): ?>
                                <div class="col-md-12 m-t-50 m-b-50">
                                 <img width="150" src="<?php echo e(loadImage(settings('siteicon'))); ?>">
                                </div>
                            <?php endif; ?>
                         <label for="inputAddress" class="col-md-12">Site Icon</label>
                         <input type="file" name="siteicon">
                         </div>
                        
                         <div class="form-group  custom-control custom-checkbox col-md-12 m-l-20">
                            <input type="checkbox" class="custom-control-input" id="customCheck1" name="sitemaintenance" 
                            <?php if(settings('sitemaintenance')): ?>
                                checked
                            <?php endif; ?> 
                            >
                            <label class="custom-control-label" for="customCheck1">Maintenance</label>
                        </div>
                        <div id="maintenanceMsg" class="form-group  col-md-12" style="display:none">
                            <label>Maintenance Message</label>
                            <textarea  class="form-control summernote" name="maintenancemessage">
                                <?php echo old('maintenancemessage' ,settings('maintenancemessage')); ?>

                            </textarea>
                        </div>
                        <button type="submit" class="btn btn-success btn-cta">Save changes</button>
                    </form>
                </div>
            </div>     
        </div>
</section>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('extra-css'); ?>
<!-- Additional library for page -->
<link rel='stylesheet' href='/adminPanel/baseassets/bundles/13fc3abb600e389b43865b1fa1697fc8f5ebf063.css'/>
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.4/summernote.css" rel="stylesheet">


<?php $__env->stopPush(); ?>
<?php $__env->startPush('extra-js'); ?>
<!-- Additional library for page -->
<script src='/adminPanel/baseassets/bundles/ba78fede76f682cd388ed2abbfd1e1568e76f8a4.js'></script>

<script src="/adminPanel/summernote/main.js"></script>
<script>
    $(document).ready(function() {

       $('.summernote').summernote({

         height:200,

     });

   });
</script>
<script>
 $(document).ready(function() {
        // Get the checkbox

      // Get the output text
      $('#customCheck1').click(function(){
      var checkBox = document.getElementById("customCheck1");

      var msg = document.getElementById("maintenanceMsg");

      // If the checkbox is checked, display the output text
      if (checkBox.checked == true){
        msg.style.display = "block";
      } else {
        msg.style.display = "none";
      }
      });
  });
 var checkBox = document.getElementById("customCheck1");
 var msg = document.getElementById("maintenanceMsg");
    // If the checkbox is checked, display the output text
 if (checkBox.checked == true){
    msg.style.display = "block";
 } else {
    msg.style.display = "none";
 }
</script>
<?php if(Session::has('success_message')): ?>
<script type="text/javascript">
  $.notify({
    // options
    icon: 'mdi mdi-check-circle',
    title: 'Success',
    message: '<?php echo e(Session::get('success_message')); ?>',
    },{
    // settings
    element: 'body',
    allow_dismiss: true,
    showProgressbar: true,
    placement: {
        from: "top",
        align: "right"
    },
    offset: 20,
    spacing: 10,
    z_index: 1031,
    delay: 5000,
    timer: 5000,
    animate: {
        enter: 'animated fadeInDown',
        exit: 'animated fadeOutUp'
    },
    icon_type: 'class',
    template: '<div data-notify="container" class="bootstrap-notify alert animated fadeInDown" role="alert" data-notify-position="top-right" style="display: inline-block; margin: 0px auto; position: fixed; transition: all 0.5s ease-in-out 0s; z-index: 10000; top: 30px; right: 28px;"><div class="progress" data-notify="progressbar"><div class="progress-bar bg-success" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%;"></div></div><div class="media "> <div class="avatar m-r-10 avatar-sm"> <div class="avatar-title bg-success rounded-circle"><span data-notify="icon" class="icon mdi mdi-check-circle"></span></div> </div><div class="media-body"><div class="font-secondary" data-notify="title">{1}</div> <span class="opacity-75" data-notify="message">{2}</span></div><a href="#" target="_blank" data-notify="url"></a> <button type="button" aria-hidden="true" class="close" data-notify="dismiss" style="position: absolute; right: 10px; top: 5px; z-index: 100002;"><span>x</span></button></div></div>' 
    });
</script>

<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>