<div class="col-md-4 m-t-50">
	<div class="card ">
		<div class="card-media">
			<div class="card-controls">
				<a href="#" class="js-card-refresh icon"></a>
			</div>
			<img class="card-img-top" src="<?php echo e(loadImage($post->image)); ?>" alt="<?php echo e($post->seo_title); ?>">
			</div>
			<div class="card-body">
				<h5 class="card-title"><?php echo e($post->title); ?></h5>
				<p class="card-text"><?php echo $post->small_description; ?></p>
				<a href="<?php echo e(route('post.show' , $post->id)); ?>" class="btn btn-primary">Show</a>
			</div>
		</div>
	</div>