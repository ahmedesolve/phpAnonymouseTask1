<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    //
    protected $fillable =['user_id','admin_id','title','slug','seo_title','small_description','body','image','images','featured',
    ];

    /**
     * Categories Relationship.
     */
    

    public function categories()
    {
        return $this->belongsToMany('App\Category');
    }


    public function user()
    {
        return $this->belongsTo('App\User');
    }

    public function admin()
    {
        return $this->belongsTo('App\Admin');
    }

    /*
    ** function to get the author from users or admin
    */
    public function author()
    {
        return $this->user_id == null ? $this->admin->name : $this->user->name; 
    }


}
