<?php

namespace App\Http\Controllers\Admin;

use App\CategoryPost;
use App\Http\Controllers\Controller;
use App\Http\Requests\PostRequest;
use App\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $posts = Post::all();
        return view('admin.posts.index')->with('posts' , $posts);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $post = Post::all();
        return view('admin.posts.create')->with('post' , $post);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PostRequest $request)
    {
        //
        $validated = $request->validated();
        //get featured
        $validated['featured'] = $validated['featured'] == 'on' ?  1 : 0;
        $validated['admin_id'] = Auth::guard('admin')->user()->id;
        if($request->hasFile('image')){
            //get the file
            $file = $request->file('image');
            //geet the folder
            $folder = 'posts';
            //rename the filename which stored in th db
            $validated['image'] = $folder . '/' . getFileName($file);
            //upload the file
            Upload($request->file('image') , $folder);
        }

        if($request->hasFile('images')){
            //get the file
            $files = $request->file('images');
            //get the folder
            $folder = 'posts';
            //rename the filename which stored in th db
            $nameToStore = '';
            foreach($files as $file){    
            //get name to store
            $nameToStore .= $folder . '/' . getFileName($file) .',';
            $validated['images'] = $nameToStore;
            //upload the file

            Upload($file , $folder);
            }
            
        }
        Post::create($validated);
        $cats = explode(',', $request->category);
            $id = Post::where('slug' , $request->slug)->first()->id;
            // Re-insert if there's at least one category checked
            $this->updatePostCategories($cats, $id);
        \Session::flash('success_message', 'Post Successfully Created'); 
        return redirect()->route('post.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $post = Post::findOrFail($id);
        $categories = $post->categories;
        //turn images into array
        $images = explode(',' , $post->images);
        //delete the last element of the array because it's empty
        unset($images[count($images) -1]);
        return view('admin.posts.view')->with(['post' => $post , 'categories' => $categories , 'images' => $images]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $post = Post::findOrFail($id);
        // $postCategories = $post->categories;
        $postCategories = Post::find($id)->categories()->get();
        // dd($postCategories);
        return view('admin.posts.edit')->with(['post' => $post , 'postCategories' => $postCategories]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(PostRequest $request, $id)
    {
        //
        $validated = $request->validated();
        //get featured
        $validated['featured'] = isset($validated['featured']) && $validated['featured'] == 'on' ?  1 : 0;
        $post = Post::findOrFail($id);
        if($request->hasFile('image')){
            // get the file
            $file = $request->file('image');
            //get the folder
            $folder = 'posts';
            //rename the filename which stored in th db
            $validated['image'] = $folder . '/' . getFileName($file);
            //check if there is already file to delete
            $delete = $post->image !== null ? $post->image : null;
            //upload the file
            Upload($file , $folder , $delete);
        }
        if($request->hasFile('images')){
            //get the file
            $files = $request->file('images');
            //get the folder
            $folder = 'posts';
            //rename the filename which stored in th db
            $nameToStore = '';
            foreach($files as $file){    
            //get name to store
            $nameToStore .= $folder . '/' . getFileName($file) .',';
            $validated['images'] = $nameToStore;
            //delete old files
            multiDel($post->images);
            //upload the file
            Upload($file , $folder);
            }
            
        }
        $cats = explode(',', $request->category);
        // delete old categories
        CategoryPost::where('post_id', $id)->delete();
        // Re-insert if there's at least one category checked
        $this->updatePostCategories($cats, $id);
        $post->update($validated);
        \Session::flash('success_message', 'Post Successfully Updated'); 
        return redirect()->route('post.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $post = Post::findOrFail($id);
        $post->delete();
        \Session::flash('success_message', 'Post Deleted Successfully'); 
        return redirect()->route('post.index');
    }

    /**
     * Remove An Array Of Records.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function bulkDelete(Request $request)
    {
        $posts = Post::whereIn('id' , $request->id);
        $posts->delete();
        \Session::flash('success_message', 'Records Deleted Successfully'); 
        return redirect()->route('post.index');
    }

    protected function updatePostCategories($cats = null, $id)
    {
        if ($cats !== null) {
        // dd($cats);
            foreach ($cats as $cat) {
                CategoryPost::create([
                    'post_id' => $id,
                    'category_id' => $cat,
                ]);
            }
        }
    }
}
