<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\SettingsRequest;
use App\Setting;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    //
    public function index()
    {
    	return view('admin.settings');
    }

    //
    public function edit(SettingsRequest $request)
    {
        $validated = $request->validated();
        //get featured
        $validated['sitemaintenance'] = isset($validated['sitemaintenance']) && $validated['sitemaintenance'] == 'on' ?  1 : 0;

        if($request->hasFile('sitelogo')){
            // get the file
            $file = $request->file('sitelogo');
            //get the folder
            $folder = 'settings';
            //rename the filename which stored in th db
            $validated['sitelogo'] = $folder . '/' . getFileName($file);
            //check if there is already file to delete
            $delete = settings('sitelogo') !== null ? settings('sitelogo') : null;
            //upload the file
            Upload($file , $folder , $delete);
        }
        if($request->hasFile('siteicon')){
            // get the file
            $file = $request->file('siteicon');
            //get the folder
            $folder = 'settings';
            //rename the filename which stored in th db
            $validated['siteicon'] = $folder . '/' . getFileName($file);
            //check if there is already file to delete
            $delete = settings('siteicon') !== null ? settings('siteicon') : null;
            //upload the file
            Upload($file , $folder , $delete);
        }
        Setting::get()->first()->update($validated);
        \Session::flash('success_message', 'Settings Successfully Updated'); 
        return redirect()->route('settings.index');
    }
}
