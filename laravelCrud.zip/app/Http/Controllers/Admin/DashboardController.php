<?php

namespace App\Http\Controllers\Admin;

use App\Admin;
use App\Category;
use App\Http\Controllers\Controller;
use App\Post;
use App\User;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('AdminAuth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $posts = Post::all()->count();
        $admins = Admin::all()->count();
        $categories = Category::all()->count();
        $users = User::all()->count();
        return view('admin.home')->with([
            'posts'  => $posts,
            'admins'  => $admins,
            'categories'  => $categories,
            'users'  => $users,
        ]);
    }

    public function search(Request $request)
    {
        $request->validate([
            'query' => 'required|min:3',
        ]);

        $query = $request->input('query');
        $posts = Post::where('title', 'like', "%$query%")
                    ->orWhere('small_description', 'like', "%$query%")
                    ->orWhere('body', 'like', "%$query%")
                    ->get();
        $categories = Category::where('name', 'like', "%$query%")->get();
        return view('admin.search-results')->with([
            'posts'  => $posts,
            'categories'  => $categories,
        ]);
    }
}
