<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Request;

class PostRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {   
        //check if the request come from edit page
        //if its true it will have id
        if(!empty(Request()->id)){
            $id = Request()->id;
            return [
            //
            'title' =>'required|string|max:255',
            'slug'  =>'required|string|max:255|unique:posts,slug,'.$id,
            'seo_title' =>'nullable|string|max:255',
            'small_description' =>'required|string',
            'body'  =>'required|string',
            'image' =>'nullable|image|max:1999|mimes:jpg,jpeg,png,gif,bmp',
            'featured'  =>'nullable',
            'images[]'  =>'nullable|image|max:1999|mimes:jpg,jpeg,png,gif,bmp',
            ];
        }else{
            return [
           //
            'title' =>'required|string|max:255',
            'slug'  =>'required|string|max:255|unique:posts',
            'seo_title' =>'nullable|string|max:255',
            'small_description' =>'required|string',
            'body'  =>'required|string',
            'image' =>'nullable|image|max:1999|mimes:jpg,jpeg,png,gif,bmp',
            'featured'  =>'nullable',
            'images[]'  =>'nullable|image|max:1999|mimes:jpg,jpeg,png,gif,bmp',
            'admin_id'  =>'nullable',
            ];
        }
        
    }
}
