<?php
/*
	** i edited the namespace attribute in RouteServiceProvider to 		mention admin directory - will find that at line 87
*/

/*login routes*/
Route::get('/login', 'Auth\AdminLoginController@showLoginForm')
	->middleware('PreventBackHistory')
	->name('admin.login');
Route::post('/login', 'Auth\AdminLoginController@login')
	->name('admin.doLogin');
/*end login routes*/
/*logout*/
Route::post('/logout','Auth\AdminLoginController@logout')
	->name('admin.logout');
/*endlogout*/

/*Reset Passwords*/
Route::group(['prefix' => 'password'], function () {
	Route::get('/reset', 'Auth\ForgotPasswordController@showLinkRequestForm')->name('admin.password.request');
	Route::post('/email', 'Auth\ForgotPasswordController@sendResetLinkEmail')->name('admin.password.email');
	Route::get('/reset/{token} ', 'Auth\ResetPasswordController@showResetForm')->name('admin.password.reset');
	Route::post('/reset', 'Auth\ResetPasswordController@reset')->name('admin.password.update');

});
/*end Reste Passwords*/

/*dashboard*/
Route::get('/','DashboardController@index')	 
		->middleware('PreventBackHistory')
		->name('admin.dashboard');
/*end dashboard*/


/*Crud Routesd*/
Route::group(['middleware' => 'AdminAuth'], function () {
	/*user Routes*/
	Route::resource('user','UsersController');
	Route::post('user/bulk-delete','UsersController@bulkDelete')->name('user.bulkDelete');
	/*end User Route*/
	/*admin Routes*/
	Route::resource('admin','AdminsController');
	Route::post('admin/bulk-delete','AdminsController@bulkDelete')->name('admin.bulkDelete');
	/*end admin Route*/
	/*categories Routes*/
	Route::resource('category','CategoryController');
	Route::post('category/bulk-delete','CategoryController@bulkDelete')->name('category.bulkDelete');
	/*end categories Route*/
	/*posts Routes*/
	Route::resource('post','PostController');
	Route::post('post/bulk-delete','PostController@bulkDelete')->name('post.bulkDelete');
	/*end posts Route*/
	/*settings Route*/
	Route::get('/settings', 'SettingsController@index')->name('settings.index');
	Route::put('/settings/update', 'SettingsController@edit')->name('settings.update');
	/*end settings Route*/
	Route::get('/search', 'DashboardController@search')->name('search');
});
/*End Crud Routesd*/