<aside class="admin-sidebar">
        <div class="admin-sidebar-brand">
            <!-- begin sidebar branding-->
            <img class="admin-brand-logo" src="<?php echo e(loadImage(settings('siteicon'))); ?>" width="40" alt="<?php echo e(settings('sitedescription')); ?>">
            <!-- end sidebar branding-->
            <div class="ml-auto">
                <!-- sidebar pin-->
                <a href="#" class="admin-pin-sidebar btn-ghost btn btn-rounded-circle"></a>
                <!-- sidebar close for mobile device-->
                <a href="#" class="admin-close-sidebar"></a>
            </div>
        </div>
        <div class="admin-sidebar-wrapper js-scrollbar">
            <ul class="menu">
                <li class="menu-item <?php echo e(setActiveNav(null)); ?>">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="menu-link">
                        <span class="menu-label">
                            <span class="menu-name">Dashboard
                            </span>
                        </span>
                        <span class="menu-icon">
                           <i class="icon-placeholder fe fe-activity "></i>
                        </span>
                    </a>
                </li>

                <li class="menu-item  <?php echo e(setActiveNav('user')); ?> ">
                    <a href="<?php echo e(route('user.index')); ?>" class="menu-link">
                        <span class="menu-label">
                            <span class="menu-name">Users
                            </span>
                        </span>
                        <span class="menu-icon">
                           <i class="icon-placeholder mdi mdi-account"></i>
                        </span>
                    </a>
                </li>

                 <li class="menu-item  <?php echo e(setActiveNav('admins')); ?> ">
                    <a href="<?php echo e(route('admin.index')); ?>" class="menu-link">
                        <span class="menu-label">
                            <span class="menu-name">Admins
                            </span>
                        </span>
                        <span class="menu-icon">
                           <i class="icon-placeholder mdi mdi-account-star"></i>
                        </span>
                    </a>
                </li>

                 <li class="menu-item  <?php echo e(setActiveNav('categories')); ?> ">
                    <a href="<?php echo e(route('category.index')); ?>" class="menu-link">
                        <span class="menu-label">
                            <span class="menu-name">Categories
                            </span>
                        </span>
                        <span class="menu-icon">
                           <i class="icon-placeholder mdi mdi-firebase"></i>
                        </span>
                    </a>
                </li>

                <li class="menu-item  <?php echo e(setActiveNav('posts')); ?> ">
                    <a href="<?php echo e(route('post.index')); ?>" class="menu-link">
                        <span class="menu-label">
                            <span class="menu-name">Posts
                            </span>
                        </span>
                        <span class="menu-icon">
                           <i class="fe fe-zap"></i>
                        </span>
                    </a>
                </li>

                <li class="menu-item  <?php echo e(setActiveNav('settings')); ?> ">
                    <a href="<?php echo e(route('settings.index')); ?>" class="menu-link">
                        <span class="menu-label">
                            <span class="menu-name">Settings
                            </span>
                        </span>
                        <span class="menu-icon">
                           <i class="icon-placeholder mdi mdi-settings"></i>
                        </span>
                    </a>
                </li>
            </ul>
        </div>
    </aside>