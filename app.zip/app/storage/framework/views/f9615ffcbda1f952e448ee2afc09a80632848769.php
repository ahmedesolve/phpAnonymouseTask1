    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" name="viewport">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta content="" name="author"/>
    
    <meta property="og:locale" content="en_US"/>
    <meta property="og:type" content="website"/>
    <meta property="og:title"
    content="Esolve Demo Just T Training And Get Rate From PhpAnonymouse Tasks Group"/>
    <meta property="og:description"
    content="<?php echo settings('sitedescription'); ?>"/>
     <meta property="og:keywords"
    content="<?php echo settings('sitekeywords'); ?>"/>
    <meta property="og:site_name" content="<?php echo settings('sitename'); ?>"/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">