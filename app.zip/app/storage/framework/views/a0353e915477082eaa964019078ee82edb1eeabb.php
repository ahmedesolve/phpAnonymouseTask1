<?php echo $__env->make('admin.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main class="admin-main  bg-pattern">
    <div class="container">
        <div class="row m-h-100">
            <div class="col-md-8 col-lg-4  m-auto">
                <div class="card shadow-lg ">
                    <div class="card-body ">
                        <div class=" padding-box-2 ">
                            <div class="text-center p-b-20 pull-up-sm">
                                <div class="avatar avatar-lg">
                                    <span class="avatar-title rounded-circle bg-pink"> <i
                                                class="mdi mdi-key-change"></i> 
                                    </span>
                                </div>

                            </div>
                            <h3 class="text-center">Reset Password</h3>
                            <?php if(session('status')): ?>
                                <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                           <form method="POST" action="<?php echo e(route('admin.password.email')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Email</label>

                                    <div class="input-group input-group-flush mb-3">
                                        <input type="email"
                                        class="form-control form-control-prepended
                                        <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                        name="email"
                                        value="<?php echo e(old('email')); ?>" required
                                        placeholder="Enter Your Email">

                                        <?php if($errors->has('email')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                        <div class="input-group-prepend">
                                            <div class="input-group-text">
                                                <span class=" mdi mdi-email "></span>
                                            </div>
                                        </div>
                                    </div>
                                    <p class="small">
                                        We will send a reset link to your registered E-Mail
                                    </p>
                                </div>


                                <div class="form-group">
                                    <button class="btn text-uppercase btn-block  btn-primary">
                                        Reset Password
                                    </button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>