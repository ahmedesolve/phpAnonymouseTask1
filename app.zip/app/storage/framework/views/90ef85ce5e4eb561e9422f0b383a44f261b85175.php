<?php $__env->startSection('content'); ?>
<section class="admin-content">
        <div class="bg-dark">
            <div class="container  m-b-30">
                <div class="row">
                    <div class="col-12 text-white p-t-40 p-b-90">
                        <h4 class="">Categories </h4>
                        <a href="<?php echo e(route('category.create')); ?>" class="btn m-b-30 ml-2 mr-2 btn-success"><i class="mdi mdi-plus"></i> Add Category
                        </a>

                        <a id="bulk-delete" href="" class="hidden btn m-b-30 ml-2 mr-2 btn-danger" data-toggle="modal" data-target="#bulkDeleteModal"><i class="mdi mdi-trash"></i> Bulk Delete
                        </a>

                    </div>
                </div>
            </div>
        </div>
        <div class="container pull-up">
            <div class="row">
                <div class="col-lg-12 m-b-30">
                    <div class="card m-b-30">
                        <div class="card-header">
                            
                        </div>
                        <div class="card-body">
                            <ul class="nav nav-pills nav-justified" id="myTab3" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#pillhome"
                                       role="tab" aria-controls="home" aria-selected="true">Table View</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#pillprofile"
                                       role="tab" aria-controls="profile" aria-selected="false">Tree View</a>
                                </li>
                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="pillhome" role="tabpanel"
                                     aria-labelledby="home-tab">
                                    <div class="table-responsive p-t-50">
                            <table id="example" class="table" style="width:100%">
                                <thead>
                                    <tr>
                                        <th><input type="checkbox" name="checkedAll[]" id="checkedAll" /></th>
                                        <th>Name</th>
                                        <th>Slug</th>
                                        <th>image</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="checkAll[]" class="checkSingle" value="<?php echo e($category->id); ?>"/>
                                        </td>
                                        <td><?php echo e($category->name); ?></td>
                                        <td><?php echo e($category->slug); ?></td>
                                        <td><img class="view-img" src="<?php echo e(loadImage($category->image)); ?>"></td>
                                        <td><?php echo $__env->make('admin.categories.buttons', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th></th>
                                        <th>Name</th>
                                        <th>Slug</th>
                                        <th>Image</th>
                                        <th>Actions</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                                    
                                </div>
                                <div class="tab-pane fade" id="pillprofile" role="tabpanel"
                                     aria-labelledby="profile-tab">
                                     <div class="row m-t-50">
                                        <div id="jstree"></div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!--card ends-->
                </div>
            </div>
        </div>
    </section>
<?php echo $__env->make('admin.layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('extra-css'); ?>
<!-- Additional library for page -->
<link rel='stylesheet' href='/adminPanel/baseassets/bundles/13fc3abb600e389b43865b1fa1697fc8f5ebf063.css'/>
<link rel="stylesheet" type="text/css" href="/adminPanel/jstree/themes/default/style.css">
<style type="text/css">
[data-notify="progressbar"] {
    margin-bottom: 0px;
    position: absolute;
    bottom: 0px;
    left: 0px;
    width: 100%;
    height: 5px;
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('extra-js'); ?>
<!-- Additional library for page -->

<script src='/adminPanel/baseassets/bundles/ba78fede76f682cd388ed2abbfd1e1568e76f8a4.js'></script>
<script src='/adminPanel/assets/js/checkbox.js'></script>
<!-- ajax functionality to bulk delete-->
<script>
    var id = [];
    $('#confirm-delete').click(function(){
        $(".checkSingle:checked").each(function() {
            id.push($(this).val());
        });
        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type:'post',
            url: '<?= url("/admin/category/bulk-delete") ?>',
            data: {  _token: '<?php echo e(csrf_token()); ?>' , id:id },
            success: function (data) {
             window.location.href = '<?php echo e(route('category.index')); ?>'
             console.log('done');

            }
        });
    });
</script>
<script type="text/javascript" src="/adminPanel/jstree/jstree.js"></script>
    <script type="text/javascript" src="/adminPanel/jstree/jstree.wholerow.js"></script>
    
    <script type="text/javascript">
    $(document).ready(function(){
        $('#jstree').jstree({
          "core" : {

            'data' : <?php echo load_cats(old('parent') , isset($productCategories) ? $productCategories : null); ?>,
            "themes" : {
              "variant" : "large"
            }
          },
          "checkbox" : {
            "keep_selected_style" : true , 
            "three_state" : false,
            "checkbox.visible" : false
            
          },
          "plugins" : [ "wholerow" , "checkbox" , "conditionalselect" ]

        });

         
       
        $('#jstree').on("changed.jstree", function (e, data) {
           var checked_ids = data.selected; 
          console.log(checked_ids);
          $('.cat_id').attr('value', checked_ids);
          // $('.parent_id').val(data.selected);
        });
        
        

    });
    </script>

<?php if(Session::has('success_message')): ?>
<script type="text/javascript">
  $.notify({
    // options
    icon: 'mdi mdi-check-circle',
    title: 'Success',
    message: '<?php echo e(Session::get('success_message')); ?>',
    },{
    // settings
    element: 'body',
    allow_dismiss: true,
    showProgressbar: true,
    placement: {
        from: "top",
        align: "right"
    },
    offset: 20,
    spacing: 10,
    z_index: 1031,
    delay: 5000,
    timer: 5000,
    animate: {
        enter: 'animated fadeInDown',
        exit: 'animated fadeOutUp'
    },
    icon_type: 'class',
    template: '<div data-notify="container" class="bootstrap-notify alert animated fadeInDown" role="alert" data-notify-position="top-right" style="display: inline-block; margin: 0px auto; position: fixed; transition: all 0.5s ease-in-out 0s; z-index: 10000; top: 30px; right: 28px;"><div class="progress" data-notify="progressbar"><div class="progress-bar bg-success" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%;"></div></div><div class="media "> <div class="avatar m-r-10 avatar-sm"> <div class="avatar-title bg-success rounded-circle"><span data-notify="icon" class="icon mdi mdi-check-circle"></span></div> </div><div class="media-body"><div class="font-secondary" data-notify="title">{1}</div> <span class="opacity-75" data-notify="message">{2}</span></div><a href="#" target="_blank" data-notify="url"></a> <button type="button" aria-hidden="true" class="close" data-notify="dismiss" style="position: absolute; right: 10px; top: 5px; z-index: 100002;"><span>x</span></button></div></div>' 
    });
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>