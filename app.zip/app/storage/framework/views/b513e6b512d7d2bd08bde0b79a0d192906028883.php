<?php $__env->startSection('content'); ?>
<section class="admin-content">
    <div class="bg-dark">
        <div class="container  m-b-30">
            <div class="row">
                <div class="col-12 text-white p-t-40 p-b-90">
                    
                </div>
            </div>
        </div>
    </div>

    <div class="container  pull-up">
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30 ">
                        <div class="card-header">
                            <h5 class="m-b-0">
                                Add New Post
                            </h5>
                        </div>
                        <div class="card-body ">
                            <?php if(session()->has('success_message')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session()->get('success_message')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <form enctype='multipart/form-data' class="" action="<?php echo e(route('post.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class="form-group floating-label col-md-12">
                                        <label>Title</label>
                                        <input type="text" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="Title" name="title">
                                    </div>
                                    <div class="form-group floating-label col-md-12">
                                        <label>Slug</label>
                                        <input placeholder="Slug" type="text" class="form-control" name="slug" value="<?php echo e(old('slug')); ?>">
                                    </div>
                                    <div class="form-group floating-label col-md-12">
                                        <label>Seo Title</label>
                                        <input placeholder="Seo Title" type="text" class="form-control" name="seo_title" value="<?php echo e(old('seo_title')); ?>">
                                    </div>  
                                    <div class="form-group col-md-12">
                                        <label>Small Description</label>
                                        <textarea class="form-control summernote" name="small_description"></textarea>
                                    </div>
                                    <div class="form-group  col-md-12">
                                        <label>Body</label>
                                        <textarea class="form-control summernote" name="body"></textarea>
                                    </div>
                                    <div id="summernote"></div>
                                    <div class="form-group  custom-control custom-checkbox col-md-12 m-l-20">
                                        <input type="checkbox" class="custom-control-input" id="customCheck1" name="featured" >
                                        <label class="custom-control-label" for="customCheck1">Featured</label>
                                    </div>
                                    <div class="form-group">
                                        <input type="file" name="image" />
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label>Category</label>
                                        <div id="jstree"></div>
                                <input type="hidden" name="category" class="cat_id">
                                    </div>
                                </div>
                                <div class="form-group col-md-12">
                                    <label class="col-md-12">Images</label>
                                    <input type="file" name="images[]" multiple/>
                                </div>
                                <button type="submit" class="btn btn-success">Save</button>

                            </form>
                        </div> 
                </div>       
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('extra-css'); ?>
<!-- Additional library for page -->
<link rel='stylesheet' href='/adminPanel/baseassets/bundles/13fc3abb600e389b43865b1fa1697fc8f5ebf063.css'/>
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.4/summernote.css" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="/adminPanel/jstree/themes/default/style.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('extra-js'); ?>
<!-- Additional library for page -->
<script src='/adminPanel/baseassets/bundles/ba78fede76f682cd388ed2abbfd1e1568e76f8a4.js'></script>
<script type="text/javascript" src="/adminPanel/jstree/jstree.js"></script>
<script type="text/javascript" src="/adminPanel/jstree/jstree.wholerow.js"></script>
<script type="text/javascript" src="/adminPanel/jstree/jstree.checkbox.js"></script>
<script src="/adminPanel/summernote/main.js"></script>
<script>
$(document).ready(function() {

           $('.summernote').summernote({

             height:200,

           });

       });
</script>
<script type="text/javascript">
    $(document).ready(function(){
        $('#jstree').jstree({
          "core" : {

            'data' : <?php echo load_cats(old('parent')); ?>,
            "themes" : {
              "variant" : "large"
            }
          },
          "checkbox" : {
            "keep_selected_style" : true , 
            "three_state" : false,
            "checkbox.visible" : false
            
          },
          "plugins" : [ "wholerow" , "checkbox" , "conditionalselect" ]

        });

         
       
        $('#jstree').on("changed.jstree", function (e, data) {
           var checked_ids = data.selected; 
          console.log(checked_ids);
          $('.cat_id').attr('value', checked_ids);
          // $('.parent_id').val(data.selected);
        });
        
        

    });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>