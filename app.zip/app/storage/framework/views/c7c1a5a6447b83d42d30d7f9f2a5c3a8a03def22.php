<header class="admin-header">
    
            <a href="#" class="sidebar-toggle" data-toggleclass="sidebar-open" data-target="body">
            </a>

            <nav class=" mr-auto my-auto">
                <ul class="nav align-items-center">

                    <li class="nav-item">
                        <a class="nav-link" data-target="#siteSearchModal" data-toggle="modal" href="#">
                            <i class=" mdi mdi-magnify mdi-24px align-middle"></i>
                        </a>
                    </li>
                </ul>
            </nav>
            <nav class=" ml-auto">
                <ul class="nav align-items-center">
                    <li class="nav-item dropdown ">
                        <a class="nav-link dropdown-toggle" href="#"   role="button" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        <div class="avatar avatar-sm avatar-online">
                             <img class="avatar-title rounded-circle bg-white" src="<?php echo e(loadImage(settings('siteicon'))); ?>" width="40" alt="<?php echo e(settings('sitedescription')); ?>">
                        </div>
                        </a>
                    <div class="dropdown-menu  dropdown-menu-right"   >
                        
                        <a class="dropdown-item"  href="<?php echo e(route('admin.logout')); ?>" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();"> Logout
                        </a>
                        <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>

                </ul>
            </nav>
</header>