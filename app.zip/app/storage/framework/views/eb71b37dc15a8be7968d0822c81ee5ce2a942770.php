<?php $__env->startSection('content'); ?>
<section class="admin-content">
    <div class="bg-dark">
        <div class="container  m-b-30">
            <div class="row">
                <div class="col-12 text-white p-t-40 p-b-90">
                    <h4 class="">Search Results </h4>
                </div>
            </div>
        </div>
    </div>

    <div class="container  pull-up">
        <div class="row">
            <?php if($categories->count() == 0): ?>
            <div class="col-12 m-b-100">
                <div class="card">
                    <div class="card-head m-b-50 m-t-50 m-l-10 text-center">
                        <h4>Sorry! There Is No Results On Categories Table</h4>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="col-12 m-b-100">
                <div class="card">
                    <div class="card-head m-t-50 m-l-10 text-center">
                        <h4><?php echo e($categories->count()); ?> Result(s) On Categories</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive p-t-10">
                            <table id="example" class="table" style="width:100%">
                                <thead>
                                    <tr>
                                        <th><input type="checkbox" name="checkedAll[]" id="checkedAll" /></th>
                                        <th>Name</th>
                                        <th>Slug</th>
                                        <th>image</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                     <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="checkAll[]" class="checkSingle" value="<?php echo e($category->id); ?>"/>
                                        </td>
                                        <td><?php echo e($category->name); ?></td>
                                        <td><?php echo e($category->slug); ?></td>
                                        <td><img class="view-img" src="<?php echo e(loadImage($category->image)); ?>"></td>
                                        <td><?php echo $__env->make('admin.categories.buttons', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th></th>
                                        <th>Name</th>
                                        <th>Slug</th>
                                        <th>Image</th>
                                        <th>Actions</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php if($posts->count() == 0): ?>
            <div class="col-12 m-b-100">
                <div class="card">
                    <div class="card-head m-b-50 m-t-50 m-l-10 text-center">

                        <h4>Sorry! There Is No Results On posts Table</h4>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="col-12 m-b-100">
                <div class="card">
                    <div class="card-head m-t-50 m-l-10 text-center">
                        <h4><?php echo e($posts->count()); ?> Result(s) On Posts</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive p-t-10">
                            <table id="example" class="table" style="width:100%">
                                <thead>
                                    <tr>
                                        <th><input type="checkbox" name="checkedAll[]" id="checkedAll" /></th>
                                        <th>Title</th>
                                        <th>Slug</th>
                                        <th>Featured</th>
                                        <th>Author</th>
                                        <th>Image</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="checkAll[]" class="checkSingle" value="<?php echo e($post->id); ?>"/>
                                        </td>
                                        <td><?php echo e($post->title); ?></td>
                                        <td><?php echo e($post->slug); ?></td>
                                        <td>
                                            <?php if($post->featured): ?>
                                            <span class="badge badge-success  text-uppercase">featured</span>
                                            <?php else: ?>
                                            <span class="badge badge-danger  text-uppercase">Not-featured</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($post->author()); ?></td>
                                        <td><img class="view-img" src="<?php echo e(loadImage($post->image)); ?>"></td>
                                        <td><?php echo $__env->make('admin.posts.buttons', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th></th>
                                        <th>Title</th>
                                        <th>Slug</th>
                                        <th>Featured</th>
                                        <th>Image</th>
                                        <th>Actions</th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php echo $__env->make('admin.layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('extra-css'); ?>
<!-- Additional library for page -->
<link rel='stylesheet' href='/adminPanel/baseassets/bundles/13fc3abb600e389b43865b1fa1697fc8f5ebf063.css'/>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('extra-js'); ?>
<!-- Additional library for page -->
<script src='/adminPanel/baseassets/bundles/ba78fede76f682cd388ed2abbfd1e1568e76f8a4.js'></script>
<script src='/adminPanel/assets/js/checkbox.js'></script>
<!-- ajax functionality to bulk delete-->

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>