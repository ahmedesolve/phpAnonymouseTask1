<form action="<?php echo e(route('settings.update')); ?>" method="POST">
<?php echo csrf_field(); ?>
<button type="aubmit">submit</button>
</form>        