<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Request;

class CategoryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {   
        //check if the request come from edit page
        //if its true it will have id
        if(!empty(Request()->id)){
            $id = Request()->id;
            return [
            //
            'name' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:categories,slug,'.$id,
            'parent_id' => 'nullable|string',
            'image' => 'nullable|image|max:1999|mimes:jpg,jpeg,png,gif,bmp',
            ];
        }else{
            return [
            //
            'name' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:categories',
            'parent_id' => 'nullable|string',
            'image' => 'nullable|image|max:1999|mimes:jpg,jpeg,png,gif,bmp',
            ];
        }
        
    }
}
