<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreAdminRequest;
use App\Http\Requests\UpdateAdminRequest;
use App\Admin;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AdminsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $admins = Admin::where('id' , '!=' , \Auth::guard('admin')->user()->id)->get();
        return view('admin.admins.index')->with('admins' , $admins);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('admin.admins.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreAdminRequest $request)
    {
        //
        $validated = $request->validated();
        $validated['password'] = Hash::make($validated['password']);
        if($request->hasFile('avatar')){
            //get the file
            $file = $request->file('avatar');
            //geet the folder
            $folder = 'admins';
            //rename the filename which stored in th db
            $validated['avatar'] = $folder . '/' . getFileName($file);
            //upload the file
            Upload($file , $folder);
        }
        Admin::create($validated);
        \Session::flash('success_message', 'Admin Successfully Created'); 
        return redirect()->route('admin.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $admin = Admin::findOrFail($id);
        $posts = $admin->posts;
        return view('admin.admins.view')->with(['admin' => $admin , 'posts' => $posts]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $admin = Admin::findOrFail($id);
        return view('admin.admins.edit')->with('admin' , $admin);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateAdminRequest $request, $id)
    {
        //
        $validated = $request->validated();
        //check if password filled or not 
        if($validated['password'] !== null){
            //hash the password if it's != null
            $validated['password'] = Hash::make($validated['password']);
        }else{
            //unset the password if it's = null
            unset($validated['password']);
        }
        
        $admin = Admin::findOrFail($id);
        if($request->hasFile('avatar')){
            //get the file
            $file = $request->file('avatar');
            //geet the folder
            $folder = 'admins';
            //rename the filename which stored in th db
            $validated['avatar'] = $folder . '/' . getFileName($file);
            //check if there is already file to delete
            $delete = $admin->avatar !== null ? $admin->avatar : null;
            //upload the file
            Upload($file , $folder , $delete);
        }
        $admin->update($validated);
        \Session::flash('success_message', 'Admin Successfully Updated'); 
        return redirect()->route('admin.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $admin = Admin::findOrFail($id);
        $admin->delete();
        \Session::flash('success_message', 'Admin Deleted Successfully'); 
        return redirect()->route('admin.index');
    }

    /**
     * Remove An Array Of Records.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function bulkDelete(Request $request)
    {
        $admins = Admin::whereIn('id' , $request->id);
        $admins->delete();
        \Session::flash('success_message', 'Records Deleted Successfully'); 
        return redirect()->route('admin.index');
    }


}
