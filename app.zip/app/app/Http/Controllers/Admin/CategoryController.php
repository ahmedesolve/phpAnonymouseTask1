<?php

namespace App\Http\Controllers\Admin;

use App\Category;
use App\Http\Controllers\Controller;
use App\Http\Requests\CategoryRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories = Category::all();
        return view('admin.categories.index')->with('categories' , $categories);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $categories = Category::all();
        return view('admin.categories.create')->with('categories' , $categories);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CategoryRequest $request)
    {
        //
        $validated = $request->validated();

        if($request->hasFile('image')){
            //get the file
            $file = $request->file('image');
            //geet the folder
            $folder = 'categories';
            //rename the filename which stored in th db
            $validated['image'] = $folder . '/' . getFileName($file);
            //upload the file
            Upload($request->file('image') , $folder);
        }
        Category::create($validated);
        \Session::flash('success_message', 'Category Successfully Created'); 
        return redirect()->route('category.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $category = Category::findOrFail($id);
        $posts = $category->posts;

        return view('admin.categories.view')->with(['category' => $category , 'posts' => $posts]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $category = Category::findOrFail($id);
        $categories = Category::where('id' , '!=' , $category->id )->get();
        return view('admin.categories.edit')->with(['category' => $category , 'categories' => $categories ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(CategoryRequest $request, $id)
    {
        //
        $validated = $request->validated();
        $category = Category::findOrFail($id);
        if($request->hasFile('image')){
            // get the file
            $file = $request->file('image');
            //get the folder
            $folder = 'categories';
            //rename the filename which stored in th db
            $validated['image'] = $folder . '/' . getFileName($file);
            //check if there is already file to delete
            $delete = $category->image !== null ? $category->image : null;
            //upload the file
            Upload($file , $folder , $delete);
        }
        $category->update($validated);
        \Session::flash('success_message', 'Category Successfully Updated'); 
        return redirect()->route('category.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $category = Category::findOrFail($id);
        $category->delete();
        \Session::flash('success_message', 'Category Deleted Successfully'); 
        return redirect()->route('category.index');
    }

    /**
     * Remove An Array Of Records.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function bulkDelete(Request $request)
    {
        $categories = Category::whereIn('id' , $request->id);
        $categories->delete();
        \Session::flash('success_message', 'Records Deleted Successfully'); 
        return redirect()->route('category.index');
    }


}
