<?php

namespace App\Http\Middleware;

use Closure;

class PreventBackHistory
{
    /**
     * Prevent User From Click Browser's Back Button After Login Or Logout.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * 
     */
    public function handle($request, Closure $next)
    {
        $response = $next($request);
        return $response->header('Cache-Control','nocache, no-store, max-age=0, must-revalidate')
            ->header('Pragma','no-cache')
            ->header('Expires','Fri, 01 Jan 1990 00:00:00 GMT');
    }
}
