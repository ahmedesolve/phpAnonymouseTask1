<?php

namespace App\Http\Controllers\Admin;

use App\Admin;
use App\Category;
use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateAdminRequest;
use App\Post;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('AdminAuth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $posts = Post::all()->count();
        $admins = Admin::all()->count();
        $categories = Category::all()->count();
        $users = User::all()->count();
        return view('admin.home')->with([
            'posts'  => $posts,
            'admins'  => $admins,
            'categories'  => $categories,
            'users'  => $users,
        ]);
    }

    public function search(Request $request)
    {
        $request->validate([
            'query' => 'required|min:3',
        ]);

        $query = $request->input('query');
        $posts = Post::where('title', 'like', "%$query%")
                    ->orWhere('small_description', 'like', "%$query%")
                    ->orWhere('body', 'like', "%$query%")
                    ->get();
        $categories = Category::where('name', 'like', "%$query%")->get();
        return view('admin.search-results')->with([
            'posts'  => $posts,
            'categories'  => $categories,
        ]);
    }

    /**
     * Show Profile Page.
     *
     * @return view
     */
    public function profile()
    {
        $user = Auth::guard('admin')->user();
        return view('admin.profile')->with([
            'user'  => $user,
        ]);
    }

    /**
     * Update Profile Info.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateAdminRequest $request, $id)
    {
        $admin = Admin::findOrFail($id);
        //
        $validated = $request->validated();
        //check if password filled or not 
        if($validated['password'] !== null){
            //hash the password if it's != null
            $validated['password'] = Hash::make($validated['password']);
        }else{
            //unset the password if it's = null
            unset($validated['password']);
        }
        if($request->hasFile('avatar')){
            //get the file
            $file = $request->file('avatar');
            //geet the folder
            $folder = 'admins';
            //rename the filename which stored in th db
            $validated['avatar'] = $folder . '/' . getFileName($file);
            //check if there is already file to delete
            $delete = $admin->avatar !== null ? $admin->avatar : null;
            //upload the file
            Upload($file , $folder , $delete);
        }
        
        $admin->update($validated);
        \Session::flash('success_message', 'You Successfully Updated Your Profile'); 
        return redirect()->route('profile');
    }
}
