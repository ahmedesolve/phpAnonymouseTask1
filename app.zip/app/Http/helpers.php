<?php

use App\Category;

	/**
     *Get the page segments 
     *
     * If no number is present, return array of page segments.
     *
     * @param  int|null  $no
     * @return Segment Or Array of Segments
     */
if(!function_exists('getSegments'))
{
    function getSegments($no = null)
    {
        if($no == null){
            return $segment = Request::segments();
        }else{
            return $segment = Request::segment($no);
        }
    }
}

	/**
     * Set the Active Class To Active Menue Item 
     *
     * If segment 2 [segment 1 is always admin in our case] = $item the retunrn the output else retunrn null
     *
     * @param  string|required  $item
     * @param  string|already set  $output
     * @return $output or null
     */
if(!function_exists('setActiveNav'))
{
    function setActiveNav($item , $output = 'active')
    {
        return getSegments(2) == $item ? $output : "";
    }
}

/**
     * Get The Image From Database Path 
     *
     * @param  string|required  $path
     */
if(!function_exists('loadImage'))
{
    function loadImage($path)
    {
        return  $path && file_exists('storage/'.$path) ? asset('storage/'.$path) : asset('storage/no-image.jpg');
    }
}


/**
     * get the uploaded file name to store
     *
     * @param  file|required  $file
     */
if(!function_exists('getFileName'))
{
    function getFileName($file)
    {
        // Get FileName With Ext
        $filnameWithExt = $file->getClientOriginalName();
        //Get Just Filename
        $filename = pathinfo($filnameWithExt , PATHINFO_FILENAME);
        //check if filename contains "," to prevent multiple images erros
        $filename = str_replace(',', '', $filename);
        // Get Just Ext
        $ext = $file->getClientOriginalExtension();
        //Filename To Store
        $fileNameToStore = $filename.'_'.time().'.'.$ext;
        
        return $fileNameToStore;
    }
}

/**
     * Upload files to the project 
     *
     * @param  file|required  $file
     * @param  string|nullable  $location
     * @param  boolean|nullable  $delete
     */
if(!function_exists('Upload'))
{
    function Upload($file , $location = null , $delete = null)
    {
        $delete !== null ? \Storage::delete($delete) : "";
        $fileNameToStore = getFileName($file);
        return $path = $file->storeAs($location, $fileNameToStore);
    }
}
/**
     * Load Categories to json to js tree 
     *
     * @param  file|required  $file
     * @param  string|nullable  $location
     * @param  boolean|nullable  $delete
     */
if(!function_exists('load_cats'))
{
    function load_cats($post_cats = null)
    {

        $cats = Category::get(['id' , 'name' , 'parent_id']);
        $cat_arr = [];
        foreach($cats as $cat)
        {
            $list_arr = [];
            // dd($post_cats);
            if($post_cats !== null){
            foreach ($post_cats as $post_cat) {
                $post_cat->id == $cat->id ? $list_arr['state'] = [
                    'selected' => true]: ""; 
                }
            }

            $list_arr['id'] = $cat->id;
            $cat->parent_id!==null?$list_arr['parent']=$cat->parent_id:$list_arr['parent']="#";
            $list_arr['text'] = $cat->name;

            array_push($cat_arr,$list_arr);
        }
        return json_encode($cat_arr,JSON_UNESCAPED_UNICODE);
    }
}

    /**
     * Get Settings 
     * @param  string|required  $key
     */
if(!function_exists('settings'))
{
    function settings($key)
    {
        return \App\Setting::get()->first()->$key;
    }
}
    /**
     * Delete multiple images 
     * @param  string|required  $images
     */
if(!function_exists('multiDel'))
{
    function multiDel($images)
    {
            $images = explode(',' , $images);
            foreach($images as $image){
                \Storage::delete($image);
            }
    }
}
