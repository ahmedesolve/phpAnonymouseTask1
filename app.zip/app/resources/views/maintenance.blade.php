@include('admin.layouts.head')

<main class="  bg-pattern">
    <div class="container">
        <div class="row m-h-100 ">
            <div class="col-md-8 col-lg-4  m-auto">
                <div class="card shadow-lg p-t-20 p-b-20">
                    <div class="card-body text-center">
                        <img width="200" alt="image" src="/adminPanel/assets/img/404.svg">
                        <h4 class="font-secondary m-t-50">{!! settings('maintenancemessage') !!}</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

@include('admin.layouts.footer')
