@include('admin.layouts.head')
@include('admin.layouts.sidebar')
<main class="admin-main">
@include('admin.layouts.nav')
@yield('content')
</main>
@include('admin.layouts.searchModal')
@include('admin.layouts.footer')