@extends('admin.index')
@section('content')
<section class="admin-content">
    <div class="bg-dark">
        <div class="container  m-b-30">
            <div class="row">
                <div class="col-12 text-white p-t-40 p-b-90">
                    
                </div>
            </div>
        </div>
    </div>

    <div class="container  pull-up">
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30 ">
                        <div class="card-header">
                            <h5 class="m-b-0">
                                Add New Category
                            </h5>
                        </div>
                        <div class="card-body ">
                            @if (session()->has('success_message'))
                                <div class="alert alert-success">
                                    {{ session()->get('success_message') }}
                                </div>
                            @endif
                            @if(count($errors) > 0)
                                <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            <form enctype='multipart/form-data' class="" action="{{ route('category.store') }}" method="POST">
                                @csrf
                                <div class="form-row">
                                    <div class="form-group floating-label col-md-12">
                                        <label>Name</label>
                                        <input type="name" class="form-control" value="{{ old('name') }}" placeholder="Name" name="name">
                                    </div>
                                    <div class="form-group floating-label col-md-12">
                                        <label>Slug</label>
                                        <input placeholder="Slug" type="text" class="form-control" name="slug" value="{{ old('slug') }}">
                                    </div>
                                    <div class="form-group floating-label col-md-12">
                                        <label>Parent</label>
                                            <select name="parent_id"  class="form-control js-select2">
                                                <option value="" selected>Choose The Parent Category</option>
                                            @foreach($categories as $category)
                                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                                            @endforeach
                                            </select>
                                    </div>
                                    <div class="form-group">
                                        <input type="file" name="image" />
                                    </div>
                                </div>


                                <button type="submit" class="btn btn-success">Save</button>

                            </form>
                        </div> 
                </div>       
            </div>
        </div>
    </div>
</section>
@endsection


@push('extra-css')
<link rel='stylesheet' href='/adminPanel/baseassets/dropzone.css'/>
@endpush
@push('extra-js')
<!-- Additional library for page -->
<script src='/adminPanel/baseassets/dropzone.js'></script>

@endpush