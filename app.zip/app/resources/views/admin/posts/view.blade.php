@extends('admin.index')
@section('content')
  <section class="admin-content">
        <div class="bg-dark">
            <div class="container  m-b-30">
                <div class="col-12 text-white p-t-40 p-b-90">
                    <h4><span class="btn btn-white-translucent"><i class="mdi mdi-format-color-text "></i></span> 
                        {{ $post->title }} Info
                    </h4>
                </div>
            </div>
        </div>
        <div class="container pull-up">
            <div class="row">
                <div class="col-lg-12 m-b-30">
                    <div class="card m-b-30">
                        <div class="card-header">
                        </div>
                        <div class="card-body">
                            <ul class="nav nav-pills nav-justified" id="myTab3" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#pillhome"
                                       role="tab" aria-controls="home" aria-selected="true">Basic Info</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#pillprofile"
                                       role="tab" aria-controls="profile" aria-selected="false">Categories</a>
                                </li>
                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="pillhome" role="tabpanel"
                                     aria-labelledby="home-tab">
                                    
                                    <hr>
<p class="p-t-20 m-b-0">Title : {{ $post->title }}</p>
<p class="p-t-20 m-b-0">Slug : {{ $post->slug }}</p>
<p class="p-t-20 m-b-0">Seo Title : {{ $post->seo_title }}</p>
<p class="p-t-20 m-b-0">Small Description : {!!  $post->small_description !!}</p>
<p class="p-t-20 m-b-0">Body : {!! $post->body !!}</p>
<p class="p-t-20 m-b-0">Image : <img src="{{ loadImage($post->image) }}" style="max-width:300px;margin-left : 30px"></p>
{{-- {{ dd($post->images) }} --}}


@if(!empty($images))
<p class="p-t-20 m-b-0">images :
 @foreach($images as $image)
<img src="{{ loadImage($image) }}" class="view-img">
 @endforeach
</p>
@endif

    
<p class="p-t-20 m-b-0">Featured : @if($post->featured)<span class="badge badge-success  text-uppercase">featured</span> @else <span class="badge badge-danger  text-uppercase">Not featured</span> @endif</p>
                                    
                                </div>
                                <div class="tab-pane fade" id="pillprofile" role="tabpanel"
                                     aria-labelledby="profile-tab">
                                     <div class="row m-t-50">
                                        @forelse($categories as $category)
                                        <p class="m-l-50"><a href="{{ route('category.show' , $category->id) }}">{{ $category->name }}</a></p>
                                        @empty 
                                        <p class="m-l-100"> Sorry! There Is No Categories Belongs To This Post</p>
                                            
                                        @endforelse
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!--card ends-->
                </div>
            </div>
        </div>
    </section>
@endsection


