@extends('admin.index')
@section('content')
<section class="admin-content">
    <div class="bg-dark">
        <div class="container  m-b-30">
            <div class="row">
                <div class="col-12 text-white p-t-40 p-b-90">
                    
                </div>
            </div>
        </div>
    </div>

    <div class="container  pull-up">
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30 ">
                        <div class="card-header">
                            <h5 class="m-b-0">
                                Edit {{ $post->name }} Information
                            </h5>
                        </div>
                        <div class="card-body ">
                            @if (session()->has('success_message'))
                                <div class="alert alert-success">
                                    {{ session()->get('success_message') }}
                                </div>
                            @endif
                            @if(count($errors) > 0)
                                <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            <form enctype='multipart/form-data' class="" action="{{ route('post.update' , $post->id) }}" method="POST">
                                @method('PUT')
                                @csrf
                                <input type="hidden" name="id" value="{{ $post->id }}">
                                <div class="form-row">
                                    <div class="form-group floating-label col-md-12">
                                        <label>Title</label>
                                        <input type="text" class="form-control" value="{{ old('name' , $post->title) }}" placeholder="Title" name="title">
                                    </div>
                                    <div class="form-group floating-label col-md-12">
                                        <label>Slug</label>
                                        <input placeholder="Slug" type="text" class="form-control" name="slug" value="{{ old('slug', $post->title) }}">
                                    </div>
                                    <div class="form-group floating-label col-md-12">
                                        <label>Seo Title</label>
                                        <input placeholder="Seo Title" type="text" class="form-control" name="seo_title" value="{{ old('seo_title', $post->seo_title) }}">
                                    </div>  
                                    <div class="form-group col-md-12">
                                        <label>Small Description</label>
                                        <textarea class="form-control summernote" name="small_description">
                                        {!! $post->small_description !!}
                                        </textarea>
                                    </div>
                                    <div class="form-group  col-md-12">
                                        <label>Body</label>
                                        <textarea class="form-control summernote" name="body">
                                            {!! $post->body !!}
                                        </textarea>
                                    </div>
                                    <div class="form-group  custom-control custom-checkbox col-md-12 m-l-20">
                                        <input type="checkbox" class="custom-control-input" id="customCheck1" name="featured" >
                                        <label class="custom-control-label" for="customCheck1">Featured</label>
                                    </div>
                                    <div class="form-group">
                                    @if(!empty($post->image))
                                        <div class="col-md-12 m-t-50 m-b-50">
                                            <img width="150" src="{{ loadImage($post->image) }}">
                                        </div>
                                    @endif
                                        <label class="col-md-12">Image</label>
                                        <input type="file" name="image" />
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label>Category</label>
                                        <div id="jstree"></div>
                                        <input type="hidden" name="category" class="cat_id">
                                    </div>
                                </div>
                                <div class="form-group col-md-12">
                                    <label class="col-md-12">Images</label>
                                    <input type="file" name="images[]" multiple/>
                                </div>
                                <button type="submit" class="btn btn-success">Save</button>

                            </form>
                        </div> 
                </div>       
            </div>
        </div>
    </div>
</section>
@endsection


@push('extra-css')
<!-- Additional library for page -->
<link rel='stylesheet' href='/adminPanel/summernote/fonts.css'/>
<link rel='stylesheet' href='/adminPanel/baseassets/bundles/13fc3abb600e389b43865b1fa1697fc8f5ebf063.css'/>
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.4/summernote.css" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="/adminPanel/jstree/themes/default/style.css">
@endpush
@push('extra-js')
<!-- Additional library for page -->
<script src='/adminPanel/baseassets/bundles/ba78fede76f682cd388ed2abbfd1e1568e76f8a4.js'></script>
<script type="text/javascript" src="/adminPanel/jstree/jstree.js"></script>
<script type="text/javascript" src="/adminPanel/jstree/jstree.wholerow.js"></script>
<script type="text/javascript" src="/adminPanel/jstree/jstree.checkbox.js"></script>
<script src="/adminPanel/summernote/main.js"></script>
<script>
$(document).ready(function() {

           $('.summernote').summernote({

             height:200,

           });

       });
</script>
<script type="text/javascript">
    $(document).ready(function(){
        $('#jstree').jstree({
          "core" : {
            'data' : {!! load_cats( $postCategories) !!},
            "themes" : {
              "variant" : "large"
            }
          },
          "checkbox" : {
            "keep_selected_style" : true , 
            "three_state" : false,
            "checkbox.visible" : false
            
          },
          "plugins" : [ "wholerow" , "checkbox" , "conditionalselect" ]

        });

         
       
        $('#jstree').on("changed.jstree", function (e, data) {
           var checked_ids = data.selected; 
          console.log(checked_ids);
          $('.cat_id').attr('value', checked_ids);
          // $('.parent_id').val(data.selected);
        });
    });
</script>
@endpush