@include('admin.layouts.head')
<main class="admin-main" style="padding : 0">
    <div class="container-fluid">
        <div class="row ">
            <div class="col-lg-4  bg-white">
                <div class="row align-items-center m-h-100">
                    <div class="mx-auto col-md-8">
                        <div class="p-b-20 text-center">
                            <p>
                                <img src="/adminPanel/assets/img/logo.svg" width="80" alt="">
                            </p>
                            <p class="admin-brand-content">
                                Esolve
                            </p>
                        </div>
                        <h3 class="text-center p-b-20 fw-400">Reset Password</h3>
                       <form method="POST" action="{{ route('admin.password.update') }}">
                        @csrf

                        <input type="hidden" name="token" value="{{ $token }}">
                            <div class="form-row">
                                <div class="form-group floating-label col-md-12">
                                    <label>Email</label>
                                    <input type="email"
                                        required 
                                        class="form-control
                                        {{ $errors->has('email') ? ' is-invalid' : '' }}" 
                                        name="email"
                                       value="{{ $email ?? old('email') }}" 
                                       required 
                                       autofocus>

                                    @if ($errors->has('email'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('email') }}</strong>
                                        </span>
                                    @endif
                                </div>
                                <div class="form-group floating-label col-md-12">
                                    <label>Password</label>
                                    <input type="password" required class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" placeholder="Enter Your Password">

                                    @if ($errors->has('password'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('password') }}</strong>
                                        </span>
                                    @endif
                                </div>
                                <div class="form-group floating-label col-md-12">
                                    <label>Password Confirmation</label>
                                   <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required
                                   placeholder="Confirm You Password">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-6 offset-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                                        <label class="form-check-label" for="remember">
                                            {{ __('Remember Me') }}
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary btn-block btn-lg">Login</button>

                        </form>
                        <p class="text-right p-t-10">
                            <a href="{{ route('admin.password.request') }}" class="text-underline">Forgot Password?</a>
                        </p>
                    </div>

                </div>
            </div>
            <div class="col-lg-8 d-none d-md-block bg-cover" style="background-image: url('/adminPanel/assets/img/login.svg');">

            </div>
        </div>
    </div>
</main>
@include('admin.layouts.footer')


