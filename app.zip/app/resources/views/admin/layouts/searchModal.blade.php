
<div class="modal modal-slide-left  fade" id="siteSearchModal" tabindex="-1" role="dialog" aria-labelledby="siteSearchModal"
aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">

        <div class="modal-body p-all-0" id="site-search">
            <button type="button" class="close light" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <div class="form-dark bg-dark text-white p-t-60 p-b-20 bg-dots" >
                <h3 class="text-uppercase    text-center  fw-300 "> Search</h3>

                <div class="container-fluid">
                    <div class="col-md-10 p-t-10 m-auto">
                        <form action="{{ route('search') }}" method="GET" class="search-form">
                            <i class="fa fa-search search-icon"></i>
                            <input type="text" name="query" id="query" value="{{ request()->input('query') }}" class="search-box search form-control form-control-lg" placeholder="Search for somthing" required>
                        </form>
                    </div>
                </div>
            </div>
            <div class="">
                <div class="bg-dark text-muted container-fluid p-b-10 text-center text-overline">
                    
                </div>
                
