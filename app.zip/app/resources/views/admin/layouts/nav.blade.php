<header class="admin-header">
    
            <a href="#" class="sidebar-toggle" data-toggleclass="sidebar-open" data-target="body">
            </a>

            <nav class=" mr-auto my-auto">
                <ul class="nav align-items-center">

                    <li class="nav-item">
                        <a class="nav-link" data-target="#siteSearchModal" data-toggle="modal" href="#">
                            <i class=" mdi mdi-magnify mdi-24px align-middle"></i>
                        </a>
                    </li>
                </ul>
            </nav>
            <nav class=" ml-auto">
                <ul class="nav align-items-center">
                    <li class="nav-item dropdown ">
                        <a class="nav-link dropdown-toggle" href="#"   role="button" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        <div class="avatar avatar-sm">
                             <img class="avatar-title rounded-circle bg-white" src="{{ loadImage(\Auth::guard('admin')->user()->avatar) }}" width="40" alt="{{ settings('sitedescription') }}">
                        </div>
                        </a>
                        <div class="dropdown-menu  dropdown-menu-right"   >
                    <a class="dropdown-item" href="{{ route('profile') }}">Account
                    </a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item"  href="{{ route('admin.logout') }}" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();"> Logout
                    </a>
                    <form id="logout-form" action="{{ route('admin.logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                    </div>
                </li>

                </ul>
            </nav>
</header>