@extends('admin.index')
@section('content')
<section class="admin-content">
    <div class="bg-dark">
        <div class="container  m-b-30">
            <div class="row">
                <div class="col-12 text-white p-t-40 p-b-90">
                    
                </div>
            </div>
        </div>
    </div>

    <div class="container  pull-up">
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30 ">
                        <div class="card-header">
                            <h5 class="m-b-0">
                                Edit {{ $category->name }} Information
                            </h5>
                        </div>
                        <div class="card-body ">
                            @if (session()->has('success_message'))
                                <div class="alert alert-success">
                                    {{ session()->get('success_message') }}
                                </div>
                            @endif
                            @if(count($errors) > 0)
                                <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            <form enctype='multipart/form-data' class="" action="{{ route('category.update' , $category->id) }}" method="POST">
                                @csrf
                                @method('PUT')
                                <input type="hidden" name="id" value="{{ $category->id }}">
                                <div class="form-row">
                                    <div class="form-group floating-label col-md-6">
                                        <label>Name</label>
                                        <input type="name" class="form-control" value="{{ old('name' , $category->name) }}" placeholder="Name" name="name">
                                    </div>
                                    <div class="form-group floating-label col-md-6">
                                        <label>Slug</label>
                                        <input type="text" class="form-control" name="slug" value="{{ old('slug' , $category->slug) }}">
                                    </div>
                                    <div class="form-group floating-label col-md-12">
                                        <label>Parent</label>
                                            <select name="parent_id" class="form-control js-select2">
                                            @foreach($categories as $cat)
<option @if($category->parent_id == $cat->id) {{ 'selcted' }} @endif value="{{ $cat->id }}">{{ $cat->name }}</option>
                                            @endforeach
                                            </select>
                                    </div>

                    @if(!empty($category->image))
                    <div class="col-md-12 m-t-50 m-b-50">
                        <img width="150" src="{{ loadImage($category->image) }}">
                    </div>
                    @endif
                                    <div class="form-group">
                                        <input type="file" name="image" />
                                    </div>
                                </div>


                                <button type="submit" class="btn btn-success">Save</button>

                            </form>
                        </div> 
                </div>       
            </div>
        </div>
    </div>
</section>
@endsection


@push('extra-css')
<!-- Additional library for page -->
<link rel='stylesheet' href='/adminPanel/baseassets/dropzone.css'/>
@endpush
@push('extra-js')
<!-- Additional library for page -->
<script src='/adminPanel/baseassets/dropzone.js'></script>

@endpush