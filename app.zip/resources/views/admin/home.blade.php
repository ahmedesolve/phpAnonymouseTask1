@extends('admin.index')
@section('content')
<!--site header ends -->    
<section class="admin-content">
    <div class="container">
        <div class="row m-t-50">
            <div class="col-12 m-b-20">
                <h5> <i class="fe fe-zap"></i> Stats</h5>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card m-b-30">
                    <div class="card-body">
                        <div class="pb-2">
                            <a href="{{ route('category.index')}}">
                                <div class="avatar avatar-lg">
                                    <div class="avatar-title bg-soft-primary rounded-circle">
                                        <i class="icon-placeholder mdi mdi-firebase"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div>
                            <a href="{{ route('category.index')}}" class="text-muted text-overline m-0">Categories</a>
                            <h1 class="fw-400">{{ $categories }}</h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card m-b-30">
                    <div class="card-body">
                        <div class="pb-2">
                            <a href="{{ route('category.index')}}">
                                <div class="avatar avatar-lg">
                                    <div class="avatar-title bg-soft-primary rounded-circle">
                                        <i class="icon-placeholder mdi mdi-newspaper"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div>
                            <a href="{{ route('category.index')}}" class="text-muted text-overline m-0">Posts</a>
                            <h1 class="fw-400">{{ $posts }}</h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card m-b-30">
                    <div class="card-body">
                        <div class="pb-2">
                            <a href="{{ route('category.index')}}">
                                <div class="avatar avatar-lg">
                                    <div class="avatar-title bg-soft-primary rounded-circle">
                                        <i class="icon-placeholder mdi mdi-account-star"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div>
                            <a href="{{ route('category.index')}}" class="text-muted text-overline m-0">Admin</a>
                            <h1 class="fw-400">{{ $admins }}</h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card m-b-30">
                    <div class="card-body">
                        <div class="pb-2">
                            <a href="{{ route('category.index')}}">
                                <div class="avatar avatar-lg">
                                    <div class="avatar-title bg-soft-primary rounded-circle">
                                        <i class="icon-placeholder mdi mdi-account"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div>
                            <a href="{{ route('category.index')}}" class="text-muted text-overline m-0">Users</a>
                            <h1 class="fw-400">{{ $users }}</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    	
    </div>
</section>
@endsection