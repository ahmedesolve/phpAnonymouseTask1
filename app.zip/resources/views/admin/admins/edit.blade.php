@extends('admin.index')
@section('content')
<section class="admin-content">
    <div class="bg-dark">
        <div class="container  m-b-30">
            <div class="row">
                <div class="col-12 text-white p-t-40 p-b-90">
                    
                </div>
            </div>
        </div>
    </div>

    <div class="container  pull-up">
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30 ">
                        <div class="card-header">
                            <h5 class="m-b-0">
                                Edit {{ $admin->name }} Information
                            </h5>
                        </div>
                        <div class="card-body ">
                            @if (session()->has('success_message'))
                                <div class="alert alert-success">
                                    {{ session()->get('success_message') }}
                                </div>
                            @endif
                            @if(count($errors) > 0)
                                <div class="alert alert-danger">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            <form enctype='multipart/form-data' class="" action="{{ route('admin.update' , $admin->id) }}" method="POST">
                                @csrf
                                @method('PUT')
                                <input type="hidden" name="id" value="{{ $admin->id }}">
                                <div class="">
                                <label class="avatar-input">
                                    <span class="avatar avatar-xl">
                                        <img src="{{ loadImage($admin->avatar) }}" alt="..."
                                             class="avatar-img rounded-circle">
                                         <span class="avatar-input-icon rounded-circle">
                                            <i class="mdi mdi-upload mdi-24px"></i>
                                        </span>
                                    </span>
                                        <input type="file" name="avatar" class="avatar-file-picker" >

                                </label>

                            </div>
                                <div class="form-row">
                                    <div class="form-group floating-label col-md-6">
                                        <label>Name</label>
                                        <input type="name" class="form-control" value="{{ old('name' , $admin->name) }}" placeholder="Name" name="name">
                                    </div>
                                    <div class="form-group floating-label col-md-6">
                                        <label>Email</label>
                                        <input type="email" class="form-control" name="email" value="{{ old('email' , $admin->email) }}">
                                    </div>
                                    <div class="form-group floating-label col-md-6">
                                        <label>Password</label>
                                        <input type="password" class="form-control" placeholder="password" name="password">
                                        <span>Leave This Blank If You Don't Want To Edit The Password</span>
                                    </div>
                                    <div class="form-group floating-label col-md-6">
                                        <label>Confirm Password</label>
                                        <input type="password" class="form-control" placeholder="Confirm Password" name="password_confirmation">
                                    </div>
                                </div>


                                <button type="submit" class="btn btn-success">Save</button>

                            </form>
                        </div> 
                </div>       
            </div>
        </div>
    </div>
</section>
@endsection


@push('extra-css')
<!-- Additional library for page -->
<link rel='stylesheet' href='/adminPanel/baseassets/bundles/13fc3abb600e389b43865b1fa1697fc8f5ebf063.css'/>
@endpush
@push('extra-js')
<!-- Additional library for page -->
<script src='/adminPanel/baseassets/bundles/ba78fede76f682cd388ed2abbfd1e1568e76f8a4.js'></script>

@endpush