<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('admin.layouts.metatags', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title><?php echo settings('sitename'); ?></title>
    <link rel="icon" type="image/x-icon" href="/adminPanel/assets/img/logo.png"/>
    <link rel="icon" href="/adminPanel/assets/img/logo.png" type="image/png" sizes="16x16">
    <link rel='stylesheet' href='/adminPanel/baseassets/css/478ccdc1892151837f9e7163badb055b8a1833a5/assets/vendor/pace/pace.css'/>
    <script src='/adminPanel/baseassets/js/3d1965f9e8e63c62b671967aafcad6603deec90c/assets/vendor/pace/pace.min.js'></script>
    <!--vendors-->
    <link rel='stylesheet' type='text/css' href='/adminPanel/baseassets/bundles/291bbeead57f19651f311362abe809b67adc3fb5.css'/>
    <link rel='stylesheet' href='/adminPanel/baseassets/bundles/dcd1663bd4b40ee5b03564aeb0245515dd3277b0.css'/>
    <link href="/adminPanel/fonts.googleapis.com/csseadf.css?family=Roboto:400,500,600" rel="stylesheet">
    <!--Material Icons-->
    <link rel='stylesheet' type='text/css' href='/adminPanel/baseassets/css/d9479893c1910021016c62f67bb4b273d80e150e/light/assets/fonts/materialdesignicons/materialdesignicons.min.css'/>
    <!--Material Icons-->
    <link rel='stylesheet' type='text/css' href='/adminPanel/baseassets/css/0940f25997c8e50e65e95510b30245d116f639f0/light/assets/fonts/feather/feather-icons.css'/>
    <!--Bootstrap + atmos Admin CSS-->
    <link rel='stylesheet' type='text/css' href='/adminPanel/baseassets/css/16e33a95bb46f814f87079394f72ef62972bd197/light/assets/css/atmos.min.css'/>
    <?php echo $__env->yieldPushContent('extra-css'); ?>
</head>