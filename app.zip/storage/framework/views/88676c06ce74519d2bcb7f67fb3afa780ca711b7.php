
<script src='/adminPanel/baseassets/bundles/9556cd6744b0b19628598270bd385082cda6a269.js'></script>
<!--page specific scripts for demo-->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="/adminPanel/baseassets/js637f?id=UA-66116118-3"></script> 

<script> 
	window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'UA-66116118-3'); </script>

<?php echo $__env->yieldPushContent('extra-js'); ?>

</body>
</html>