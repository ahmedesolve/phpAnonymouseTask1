<?php $__env->startSection('content'); ?>
<section class="admin-content">
    <div class="bg-dark">
        <div class="container  m-b-30">
            <div class="row">
                <div class="col-12 text-white p-t-40 p-b-90">
                    
                </div>
            </div>
        </div>
    </div>

    <div class="container  pull-up">
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30 ">
                        <div class="card-header">
                            <h5 class="m-b-0">
                                Add New Category
                            </h5>
                        </div>
                        <div class="card-body ">
                            <?php if(session()->has('success_message')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session()->get('success_message')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <form enctype='multipart/form-data' class="" action="<?php echo e(route('category.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class="form-group floating-label col-md-12">
                                        <label>Name</label>
                                        <input type="name" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="Name" name="name">
                                    </div>
                                    <div class="form-group floating-label col-md-12">
                                        <label>Slug</label>
                                        <input placeholder="Slug" type="text" class="form-control" name="slug" value="<?php echo e(old('slug')); ?>">
                                    </div>
                                    <div class="form-group floating-label col-md-12">
                                        <label>Parent</label>
                                            <select  class="form-control js-select2">
                                                <option disable selected>Choose The Parent Category</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                    </div>
                                    <div class="form-group">
                                        <input type="file" name="image" />
                                    </div>
                                </div>


                                <button type="submit" class="btn btn-success">Save</button>

                            </form>
                        </div> 
                </div>       
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('extra-css'); ?>
<link rel='stylesheet' href='/adminPanel/baseassets/dropzone.css'/>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('extra-js'); ?>
<!-- Additional library for page -->
<script src='/adminPanel/baseassets/dropzone.js'></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>