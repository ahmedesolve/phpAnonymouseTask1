<?php $__env->startSection('content'); ?>
<section class="admin-content ">
    <div class="bg-dark bg-dots m-b-30">
        <div class="container">
            <div class="row p-b-60 p-t-60">

                <div class="col-lg-8 text-center mx-auto text-white p-b-30">
                    <div class="m-b-10">
                        <div class="avatar avatar-lg ">
                            <div class="avatar-title bg-info rounded-circle mdi mdi-account "></div>
                        </div>
                    </div>
                    <h3>Edit Your Profie</h3>
                </div>


            </div>
        </div>
    </div>
    <section class="pull-up">
        <div class="container">
            <div class="row ">
                <div class="col-lg-8 mx-auto  mt-2">
                    <div class="card py-3 m-b-30">
                     <div class="card-body">
                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                         <form enctype='multipart/form-data' action="<?php echo e(route('profile.update' , $user->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                            <div class="">
                                <label class="avatar-input">
                                    <span class="avatar avatar-xl">
                                        <img src="<?php echo e(loadImage($user->avatar)); ?>" alt="..."
                                             class="avatar-img rounded-circle">
                                         <span class="avatar-input-icon rounded-circle">
                                            <i class="mdi mdi-upload mdi-24px"></i>
                                        </span>
                                    </span>
                                        <input type="file" name="avatar" class="avatar-file-picker" >

                                </label>

                            </div>
                            <div class="form-row">
                                    <div class="form-group floating-label col-md-12">
                                        <label>Name</label>
                                        <input type="name" class="form-control" value="<?php echo e(old('name' , $user->name)); ?>" placeholder="Name" name="name">
                                    </div>
                                    <div class="form-group floating-label col-md-12">
                                        <label>Email</label>
                                        <input type="email" class="form-control" name="email" value="<?php echo e(old('email' , $user->email)); ?>"  placeholder="email">
                                    </div>
                                    <div class="form-group floating-label col-md-6">
                                        <label>Password</label>
                                        <input type="password" class="form-control" placeholder="password" name="password">
                                        <span>Leave This Blank If You Don't Want To Edit The Password</span>
                                    </div>
                                    <div class="form-group floating-label col-md-6">
                                        <label>Confirm Password</label>
                                        <input type="password" class="form-control" placeholder="Confirm Password" name="password_confirmation">
                                    </div>
                                </div>
                         
                        <button type="submit" class="btn btn-success btn-cta">Save changes</button>
                    </form>
                </div>
            </div>     
        </div>
</section>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('extra-css'); ?>
<!-- Additional library for page -->
<link rel='stylesheet' href='/adminPanel/baseassets/bundles/13fc3abb600e389b43865b1fa1697fc8f5ebf063.css'/>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('extra-js'); ?>
<!-- Additional library for page -->
<script src='/adminPanel/baseassets/bundles/ba78fede76f682cd388ed2abbfd1e1568e76f8a4.js'></script>
<?php if(Session::has('success_message')): ?>
<script type="text/javascript">
  $.notify({
    // options
    icon: 'mdi mdi-check-circle',
    title: 'Success',
    message: '<?php echo e(Session::get('success_message')); ?>',
    },{
    // settings
    element: 'body',
    allow_dismiss: true,
    showProgressbar: true,
    placement: {
        from: "top",
        align: "right"
    },
    offset: 20,
    spacing: 10,
    z_index: 1031,
    delay: 5000,
    timer: 5000,
    animate: {
        enter: 'animated fadeInDown',
        exit: 'animated fadeOutUp'
    },
    icon_type: 'class',
    template: '<div data-notify="container" class="bootstrap-notify alert animated fadeInDown" role="alert" data-notify-position="top-right" style="display: inline-block; margin: 0px auto; position: fixed; transition: all 0.5s ease-in-out 0s; z-index: 10000; top: 30px; right: 28px;"><div class="progress" data-notify="progressbar"><div class="progress-bar bg-success" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%;"></div></div><div class="media "> <div class="avatar m-r-10 avatar-sm"> <div class="avatar-title bg-success rounded-circle"><span data-notify="icon" class="icon mdi mdi-check-circle"></span></div> </div><div class="media-body"><div class="font-secondary" data-notify="title">{1}</div> <span class="opacity-75" data-notify="message">{2}</span></div><a href="#" target="_blank" data-notify="url"></a> <button type="button" aria-hidden="true" class="close" data-notify="dismiss" style="position: absolute; right: 10px; top: 5px; z-index: 100002;"><span>x</span></button></div></div>' 
    });
</script>

<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>