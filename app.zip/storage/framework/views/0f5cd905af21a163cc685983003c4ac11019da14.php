<?php $__env->startSection('content'); ?>
<!--site header ends -->    
<section class="admin-content">
    <div class="container">
        <div class="row m-t-50">
            <div class="col-12 m-b-20">
                <h5> <i class="fe fe-zap"></i> Stats</h5>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card m-b-30">
                    <div class="card-body">
                        <div class="pb-2">
                            <a href="<?php echo e(route('category.index')); ?>">
                                <div class="avatar avatar-lg">
                                    <div class="avatar-title bg-soft-primary rounded-circle">
                                        <i class="icon-placeholder mdi mdi-firebase"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div>
                            <a href="<?php echo e(route('category.index')); ?>" class="text-muted text-overline m-0">Categories</a>
                            <h1 class="fw-400"><?php echo e($categories); ?></h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card m-b-30">
                    <div class="card-body">
                        <div class="pb-2">
                            <a href="<?php echo e(route('category.index')); ?>">
                                <div class="avatar avatar-lg">
                                    <div class="avatar-title bg-soft-primary rounded-circle">
                                        <i class="icon-placeholder mdi mdi-newspaper"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div>
                            <a href="<?php echo e(route('category.index')); ?>" class="text-muted text-overline m-0">Posts</a>
                            <h1 class="fw-400"><?php echo e($posts); ?></h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card m-b-30">
                    <div class="card-body">
                        <div class="pb-2">
                            <a href="<?php echo e(route('category.index')); ?>">
                                <div class="avatar avatar-lg">
                                    <div class="avatar-title bg-soft-primary rounded-circle">
                                        <i class="icon-placeholder mdi mdi-account-star"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div>
                            <a href="<?php echo e(route('category.index')); ?>" class="text-muted text-overline m-0">Admin</a>
                            <h1 class="fw-400"><?php echo e($admins); ?></h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="card m-b-30">
                    <div class="card-body">
                        <div class="pb-2">
                            <a href="<?php echo e(route('category.index')); ?>">
                                <div class="avatar avatar-lg">
                                    <div class="avatar-title bg-soft-primary rounded-circle">
                                        <i class="icon-placeholder mdi mdi-account"></i>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div>
                            <a href="<?php echo e(route('category.index')); ?>" class="text-muted text-overline m-0">Users</a>
                            <h1 class="fw-400"><?php echo e($users); ?></h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    	
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>