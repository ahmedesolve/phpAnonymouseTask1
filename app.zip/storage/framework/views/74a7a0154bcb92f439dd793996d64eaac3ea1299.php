<?php $__env->startSection('content'); ?>
<section class="admin-content">
    <div class="bg-dark">
        <div class="container  m-b-30">
            <div class="row">
                <div class="col-12 text-white p-t-40 p-b-90">
                    
                </div>
            </div>
        </div>
    </div>

    <div class="container  pull-up">
        <div class="row">
            <div class="col-12">
                <div class="card m-b-30 ">
                        <div class="card-header">
                            <h5 class="m-b-0">
                                Edit <?php echo e($category->name); ?> Information
                            </h5>
                        </div>
                        <div class="card-body ">
                            <?php if(session()->has('success_message')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session()->get('success_message')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <form enctype='multipart/form-data' class="" action="<?php echo e(route('category.update' , $category->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <input type="hidden" name="id" value="<?php echo e($category->id); ?>">
                                <div class="form-row">
                                    <div class="form-group floating-label col-md-6">
                                        <label>Name</label>
                                        <input type="name" class="form-control" value="<?php echo e(old('name' , $category->name)); ?>" placeholder="Name" name="name">
                                    </div>
                                    <div class="form-group floating-label col-md-6">
                                        <label>Slug</label>
                                        <input type="text" class="form-control" name="slug" value="<?php echo e(old('slug' , $category->slug)); ?>">
                                    </div>
                                    <div class="form-group floating-label col-md-12">
                                        <label>Parent</label>
                                            <select  class="form-control js-select2">
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option <?php if($category->parent_id == $cat->id): ?> <?php echo e('selcted'); ?> <?php endif; ?> value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                    </div>

                    <?php if(!empty($category->image)): ?>
                    <div class="col-md-12 m-t-50 m-b-50">
                        <img width="150" src="<?php echo e(loadImage($category->image)); ?>">
                    </div>
                    <?php endif; ?>
                                    <div class="form-group">
                                        <input type="file" name="image" />
                                    </div>
                                </div>


                                <button type="submit" class="btn btn-success">Save</button>

                            </form>
                        </div> 
                </div>       
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('extra-css'); ?>
<!-- Additional library for page -->
<link rel='stylesheet' href='/adminPanel/baseassets/dropzone.css'/>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('extra-js'); ?>
<!-- Additional library for page -->
<script src='/adminPanel/baseassets/dropzone.js'></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>