<?php $__env->startSection('content'); ?>
  <section class="admin-content">
        <div class="bg-dark">
            <div class="container  m-b-30">
                <div class="col-12 text-white p-t-40 p-b-90">
                    <h4><span class="btn btn-white-translucent"><i class="mdi mdi-format-color-text "></i></span> 
                        <?php echo e($post->title); ?> Info
                    </h4>
                </div>
            </div>
        </div>
        <div class="container pull-up">
            <div class="row">
                <div class="col-lg-12 m-b-30">
                    <div class="card m-b-30">
                        <div class="card-header">
                        </div>
                        <div class="card-body">
                            <ul class="nav nav-pills nav-justified" id="myTab3" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#pillhome"
                                       role="tab" aria-controls="home" aria-selected="true">Basic Info</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#pillprofile"
                                       role="tab" aria-controls="profile" aria-selected="false">Categories</a>
                                </li>
                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="pillhome" role="tabpanel"
                                     aria-labelledby="home-tab">
                                    
                                    <hr>
<p class="p-t-20 m-b-0">Title : <?php echo e($post->title); ?></p>
<p class="p-t-20 m-b-0">Slug : <?php echo e($post->slug); ?></p>
<p class="p-t-20 m-b-0">Seo Title : <?php echo e($post->seo_title); ?></p>
<p class="p-t-20 m-b-0">Small Description : <?php echo $post->small_description; ?></p>
<p class="p-t-20 m-b-0">Body : <?php echo $post->body; ?></p>
<p class="p-t-20 m-b-0">Image : <img src="<?php echo e(loadImage($post->image)); ?>" style="max-width:300px;margin-left : 30px"></p>



<?php if(!empty($images)): ?>
<p class="p-t-20 m-b-0">images :
 <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<img src="<?php echo e(loadImage($image)); ?>" class="view-img">
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</p>
<?php endif; ?>

    
<p class="p-t-20 m-b-0">Featured : <?php if($post->featured): ?><span class="badge badge-success  text-uppercase">featured</span> <?php else: ?> <span class="badge badge-danger  text-uppercase">Not featured</span> <?php endif; ?></p>
                                    
                                </div>
                                <div class="tab-pane fade" id="pillprofile" role="tabpanel"
                                     aria-labelledby="profile-tab">
                                     <div class="row m-t-50">
                                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <p class="m-l-50"><a href="<?php echo e(route('category.show' , $category->id)); ?>"><?php echo e($category->name); ?></a></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                                        <p class="m-l-100"> Sorry! There Is No Categories Belongs To This Post</p>
                                            
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!--card ends-->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>