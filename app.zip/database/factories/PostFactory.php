<?php

use Faker\Generator as Faker;

$factory->define(App\Post::class, function (Faker $faker) {
	$name = $faker->text(20);
    return [
		'user_id'			=>rand(1,10),
		'title'				=>$name,
		'image'				=>'posts/1.jpg',
		'images'			=>'posts/1.jpg,posts/1.jpg,posts/1.jpg',
		'slug'				=>str_slug($name),
		'seo_title'			=>$faker->text(25),
		'small_description'	=>$faker->text(100),
		'body'				=>$faker->text(),
		'featured'			=>rand(0,1),
    ];
});
