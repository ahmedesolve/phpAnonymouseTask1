<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->increments('id');
            $table->string('sitename')->default('Esolve Task');
            $table->string('siteemail')->default('ahmed@esolve-eg.com');
            $table->string('sitekeywords')->default('esolve,phpAnonymouse,tasks');
            $table->string('sitelogo')->default('settings/logo.png');
            $table->string('siteicon')->default('settings/icon.png');
            $table->text('sitedescription')->default('This Is A Small Task From PhpAnonymous Tasks Group');
            $table->boolean('sitemaintenance')->default(false);
            $table->text('maintenancemessage')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('settings');
    }
}
