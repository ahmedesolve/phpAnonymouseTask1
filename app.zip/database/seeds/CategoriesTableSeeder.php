<?php

use App\Category;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class CategoriesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $now = Carbon::now()->toDateTimeString();

        Category::insert([
            [
             'name' => 'romantic',
             'slug' => 'romantic',
             'image' => 'categories/1.png',
             'created_at' => $now,
             'updated_at' => $now
            ],
            [
            'name' => 'drama',
            'slug' => 'drama',
            'image' => 'categories/2.png',
            'created_at' => $now,
            'updated_at' => $now
            ],

            [
            'name' => 'science fiction',
            'slug' => 'science-fiction',
            'image' => 'categories/3.png',
            'created_at' => $now,
            'updated_at' => $now
            ],
            [
            'name' => 'psychology',
            'slug' => 'psychology',
            'image' => 'categories/1.png',
            'created_at' => $now,
            'updated_at' => $now
            ],
            [
            'name' => 'books',
            'slug' => 'books',
            'image' => 'categories/2.png',
            'created_at' => $now,
            'updated_at' => $now
            ],
            [
            'name' => 'philosophy',
            'slug' => 'philosophy',
            'image' => 'categories/3.png',
            'created_at' => $now,
            'updated_at' => $now
            ],
            [
            'name' => 'kids',
            'slug' => 'kids',
            'image' => 'categories/1.png',
            'created_at' => $now,
            'updated_at' => $now
            ],
            [
            'name' => 'accessories',
            'slug' => 'accessories',
            'image' => 'categories/2.png',
            'created_at' => $now,
            'updated_at' => $now
            ],
        ]);
        
            for($i = 1 ; $i < 5 ; $i++){
                Category::create([
                'name' => 'category '.$i,
                'slug' => 'category_'.$i,
                'created_at' => $now,
                'updated_at' => $now,
                'parent_id' => 1
                ]); 
                    
            }
            for($i = 50 ; $i <= 54 ; $i++){
                Category::create([
                'name' => 'subcategory '.$i,
                'slug' => 'subcategory_'.$i,
                'created_at' => $now,
                'updated_at' => $now,
                'parent_id' => 9
                ]); 
                    
            }
            for($i = 5 ; $i <= 9 ; $i++){
                Category::create([
                'name' => 'subcategory '.$i,
                'slug' => 'subcategory_'.$i,
                'created_at' => $now,
                'updated_at' => $now,
                'parent_id' => 10
                ]); 
                    
            }
            for($i = 10 ; $i <= 14 ; $i++){
                Category::create([
                'name' => 'subcategory '.$i,
                'slug' => 'subcategory_'.$i,
                'created_at' => $now,
                'updated_at' => $now,
                'parent_id' => 11
                ]); 
                    
            }
            for($i = 15 ; $i <= 19 ; $i++){
                Category::create([
                'name' => 'subcategory '.$i,
                'slug' => 'subcategory_'.$i,
                'created_at' => $now,
                'updated_at' => $now,
                'parent_id' => 12
                ]); 
                    
            }



            /////////////////

            for($i = 1 ; $i < 5 ; $i++){
                Category::create([
                'name' => 'seccategory '.$i,
                'slug' => 'secegory_'.$i,
                'created_at' => $now,
                'updated_at' => $now,
                'parent_id' => 2
                ]); 
                    
            }
           
            

            

            /////////////////

            
            for($i = 1 ; $i <= 4 ; $i++){
                Category::create([
                'name' => 'fosubcategory '.$i,
                'slug' => 'fosubcategory_'.$i,
                'created_at' => $now,
                'updated_at' => $now,
                'parent_id' => 9 + 24
                ]); 
                    
            }
            for($i = 5 ; $i <= 9 ; $i++){
                Category::create([
                'name' => 'fosubcategory '.$i,
                'slug' => 'fosubcategory_'.$i,
                'created_at' => $now,
                'updated_at' => $now,
                'parent_id' => 10 +24
                ]); 
                    
            }
            for($i = 10 ; $i <= 14 ; $i++){
                Category::create([
                'name' => 'fosubcategory '.$i,
                'slug' => 'fosubcategory_'.$i,
                'created_at' => $now,
                'updated_at' => $now,
                'parent_id' => 11 + 24
                ]); 
                    
            }
            for($i = 15 ; $i <= 19 ; $i++){
                Category::create([
                'name' => 'fosubcategory '.$i,
                'slug' => 'fosubcategory_'.$i,
                'created_at' => $now,
                'updated_at' => $now,
                'parent_id' => 12 +24
                ]); 
                    
            }
    }
}
